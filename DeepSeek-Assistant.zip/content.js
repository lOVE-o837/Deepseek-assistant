﻿// DeepSeek Assistant - Content Script
// Injects into DeepSeek chat pages to provide search & bookmark features

(function () {
  'use strict';

  // ==================== 常量 ====================
  const PANEL_ID = 'ds-assistant-panel-iframe';
  const PANEL_OVERLAY_ID = 'ds-assistant-overlay';
  const FLOAT_BTN_ID = 'ds-assistant-float-btn';
  const STORAGE_PREFIX = 'ds_assistant_';

  // ==================== 状态 ====================
  let floatBtn = null;
  let panelIframe = null;
  let dragState = null; // { offsetX, offsetY, onMouseMove, onMouseUp }
  let settings = {
    theme: 'deep-blue',
    fontSize: 'medium',
    enableFloatButton: true,
    maxHistoryItems: 50,
    customThemeColors: null
  };

  // ==================== 初始化 ====================
  function init() {
    // 先清理残留的旧 DOM 元素（如果是从 executeScript 重新注入的）
    const oldIframe = document.getElementById(PANEL_ID);
    if (oldIframe) oldIframe.remove();
    const oldOverlay = document.getElementById(PANEL_OVERLAY_ID);
    if (oldOverlay) oldOverlay.remove();
    const oldFloat = document.getElementById(FLOAT_BTN_ID);
    if (oldFloat) oldFloat.remove();
    const oldToast = document.getElementById('ds-assistant-toast-container');
    if (oldToast) oldToast.remove();

    loadSettings().then(() => {
      injectFloatButton();
      injectPanelIframe();
      setupMessageListener();
      setupKeyboardShortcuts();
      // 初始化消息级收藏系统
      initMessageBookmarkSystem();
      // 初始化完成后向 panel.js 发送就绪信号
      setTimeout(() => sendContentReady(), 100);
      // 检查 URL hash 中是否有消息收藏跳转指令
      checkMessageScrollHash();
    });

    // 页面卸载时清理所有注入的 DOM
    window.addEventListener('beforeunload', cleanup);
  }

  function cleanup() {
    const ids = [PANEL_ID, PANEL_OVERLAY_ID, FLOAT_BTN_ID, 'ds-assistant-toast-container'];
    ids.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.remove();
    });
    panelIframe = null;
    floatBtn = null;
  }

  // ==================== 设置加载 ====================
  async function loadSettings() {
    try {
      const stored = await chrome.storage.local.get([
        STORAGE_PREFIX + 'theme',
        STORAGE_PREFIX + 'fontSize',
        STORAGE_PREFIX + 'enableFloatButton',
        STORAGE_PREFIX + 'maxHistoryItems',
        STORAGE_PREFIX + 'customThemeColors'
      ]);
      if (stored[STORAGE_PREFIX + 'theme'] !== undefined) settings.theme = stored[STORAGE_PREFIX + 'theme'];
      if (stored[STORAGE_PREFIX + 'fontSize'] !== undefined) settings.fontSize = stored[STORAGE_PREFIX + 'fontSize'];
      if (stored[STORAGE_PREFIX + 'enableFloatButton'] !== undefined) settings.enableFloatButton = stored[STORAGE_PREFIX + 'enableFloatButton'];
      if (stored[STORAGE_PREFIX + 'maxHistoryItems'] !== undefined) settings.maxHistoryItems = stored[STORAGE_PREFIX + 'maxHistoryItems'];
      if (stored[STORAGE_PREFIX + 'customThemeColors'] !== undefined) settings.customThemeColors = stored[STORAGE_PREFIX + 'customThemeColors'];
    } catch (e) {
      console.warn('[DeepSeek-Assistant] Failed to load settings:', e);
    }
  }

  // ==================== 消息监听 ====================
  function setupMessageListener() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      (async () => {
        try {
          switch (message.action) {
            case 'toggle-panel':
              togglePanel();
              sendResponse({ success: true });
              break;
            case 'get-panel-state':
              sendResponse({ visible: panelIframe ? panelIframe.classList.contains('visible') : false });
              break;
            case 'fetch-sidebar-conversations':
              const conversations = await fetchSidebarConversations();
              sendResponse({ success: true, conversations });
              break;
            case 'search-current-page':
              const results = searchCurrentPage(message.query);
              sendResponse({ success: true, results });
              break;
            case 'scroll-to-result':
              scrollToResult(message.index);
              sendResponse({ success: true });
              break;
            case 'get-page-title':
              sendResponse({ title: getPageTitle() });
              break;
            case 'open-url':
              window.open(message.url, '_blank');
              sendResponse({ success: true });
              break;
            case 'settings-changed':
              Object.assign(settings, message.settings);
              updateFloatButtonVisibility();
              sendResponse({ success: true });
              break;
            case 'close-panel':
              hidePanel();
              sendResponse({ success: true });
              break;
            case 'minimize-panel':
              hidePanel();
              sendResponse({ success: true });
              break;
            case 'toggle-float-btn':
              settings.enableFloatButton = message.enabled;
              updateFloatButtonVisibility();
              sendResponse({ success: true });
              break;
            case 'open-about-overlay':
              openAboutOverlay();
              sendResponse({ success: true });
              break;
            case 'close-about-overlay':
              closeAboutOverlay();
              sendResponse({ success: true });
              break;
            case 'toggle-bookmark':
              console.log('[DeepSeek-Assistant][msg:toggle-bookmark] 接收到 toggle-bookmark 消息，调用 bookmarkCurrentPage()');
              bookmarkCurrentPage();
              sendResponse({ success: true });
              break;
            case 'bookmark-from-panel':
              console.log('[DeepSeek-Assistant][msg:bookmark-from-panel] 面板右键收藏，与 ⭐ 按钮路径完全对齐');
              bookmarkCurrentPage();
              sendResponse({ success: true });
              break;
            default:
              sendResponse({ success: false, error: 'Unknown action' });
          }
        } catch (e) {
          sendResponse({ success: false, error: e.message });
        }
      })();
      return true;
    });

    // 监听来自 panel iframe 的 DOM postMessage（最小化/关闭/拖动/覆盖层）
    window.addEventListener('message', (event) => {
      if (!event.data || !event.data.action) return;
      if (event.data.action === 'minimize-panel') hidePanel();
      if (event.data.action === 'close-panel') hidePanel();
      if (event.data.action === 'drag-start') startDrag(event.data.offsetX, event.data.offsetY);
      if (event.data.action === 'close-about-overlay') closeAboutOverlay();
    });
  }

  // ==================== 键盘快捷键 ====================
  // Alt+K 和 Ctrl+Shift+X 已在 manifest.json 注册为浏览器命令，
  // 由 background.js 的 chrome.commands.onCommand 处理（通过 message 转发到 content.js），
  // 此处不再监听 keydown 以规避与浏览器命令的双击冲突。
  function setupKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && panelIframe && panelIframe.classList.contains('visible')) {
        hidePanel();
      }
    });
  }

  // ==================== 浮动按钮 ====================
  function injectFloatButton() {
    if (document.getElementById(FLOAT_BTN_ID)) return;

    floatBtn = document.createElement('div');
    floatBtn.id = FLOAT_BTN_ID;
    floatBtn.innerHTML = '\u2B50';
    floatBtn.title = '收藏当前对话 / 拖拽移动 (Alt+K 打开面板)';
    floatBtn.style.cssText = [
      'position: fixed;',
      'bottom: 120px;',
      'right: 24px;',
      'width: 44px;',
      'height: 44px;',
      'border-radius: 50%;',
      'background: var(--ds-primary, #1890ff);',
      'color: #fff;',
      'font-size: 20px;',
      'display: flex;',
      'align-items: center;',
      'justify-content: center;',
      'cursor: pointer;',
      'z-index: 9998;',
      'box-shadow: 0 4px 12px rgba(0,0,0,0.15);',
      'transition: all 0.3s ease;',
      'border: none;',
      'user-select: none;'
    ].join('');

    // 拖拽功能 + 防误触
    let isDragging = false;
    let dragStartX = 0;
    let dragStartY = 0;
    let btnStartRight = 0;
    let btnStartBottom = 0;
    let hasMoved = false;

    floatBtn.addEventListener('mousedown', (e) => {
      isDragging = true;
      hasMoved = false;
      dragStartX = e.clientX;
      dragStartY = e.clientY;
      btnStartRight = parseInt(floatBtn.style.right) || 24;
      btnStartBottom = parseInt(floatBtn.style.bottom) || 120;
      floatBtn.style.transition = 'none';
      e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      const dx = dragStartX - e.clientX;
      const dy = dragStartY - e.clientY;
      // 右边界增加 = 向左拖动 → right值增加
      // 下边界增加 = 向上拖动 → bottom值增加
      floatBtn.style.right = (btnStartRight + dx) + 'px';
      floatBtn.style.bottom = (btnStartBottom + dy) + 'px';
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
        hasMoved = true;
      }
    });

    document.addEventListener('mouseup', () => {
      if (isDragging) {
        floatBtn.style.transition = 'all 0.3s ease';
        isDragging = false;
      }
    });

    floatBtn.addEventListener('click', async (e) => {
      // 防误触：如果拖拽移动过，不触发点击
      if (hasMoved) return;
      // 弹出确认框
      showConfirmDialog(
        '⭐ 收藏当前对话',
        '是否收藏当前对话？',
        () => { bookmarkCurrentPage(); },
        () => {} // 取消不做任何事
      );
    });

    floatBtn.addEventListener('mouseenter', () => {
      floatBtn.style.transform = 'scale(1.1)';
      floatBtn.style.boxShadow = '0 6px 20px rgba(0,0,0,0.25)';
    });
    floatBtn.addEventListener('mouseleave', () => {
      floatBtn.style.transform = 'scale(1)';
      floatBtn.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
    });

    document.body.appendChild(floatBtn);
    updateFloatButtonVisibility();
  }

  function updateFloatButtonVisibility() {
    if (!floatBtn) return;
    floatBtn.style.display = settings.enableFloatButton ? 'flex' : 'none';
  }

  // ==================== 面板 iframe ====================
  function injectPanelIframe() {
    // ★ 防重复：先清理 DOM 中已有的旧 iframe 和 overlay
    const existingIframe = document.getElementById(PANEL_ID);
    if (existingIframe) {
      existingIframe.remove();
    }
    const existingOverlay = document.getElementById(PANEL_OVERLAY_ID);
    if (existingOverlay) {
      existingOverlay.remove();
    }

    panelIframe = document.createElement('iframe');
    panelIframe.id = PANEL_ID;
    panelIframe.src = chrome.runtime.getURL('panel.html');
    panelIframe.style.cssText = [
      'position: fixed;',
      'top: 50%;',
      'left: 50%;',
      'transform: translate(-50%, -50%) scale(0.9);',
      'z-index: 2147483647;',
      'width: 480px;',
      'height: 88vh;',
      'min-height: 600px;',
      'max-width: 92vw;',
      'max-height: 88vh;',
      'border: none;',
      'border-radius: 14px;',
      'box-shadow: 0 12px 48px rgba(0,0,0,0.25);'
    ].join('');
    // opacity 和 pointer-events 由 CSS .visible class 控制
    panelIframe.classList.remove('visible');

    // 注入遮罩层
    const overlay = document.createElement('div');
    overlay.id = PANEL_OVERLAY_ID;
    overlay.style.cssText = [
      'position: fixed;',
      'inset: 0;',
      'z-index: 2147483645;',
      'background: rgba(0,0,0,0.4);'
    ].join('');
    // opacity 和 pointer-events 由 CSS .visible class 控制
    overlay.classList.remove('visible');
    overlay.addEventListener('click', () => hidePanel());
    document.body.appendChild(overlay);

    document.body.appendChild(panelIframe);
  }

  function togglePanel() {
    if (!panelIframe) return;
    const visible = panelIframe.classList.contains('visible');
    if (visible) {
      hidePanel();
    } else {
      showPanel();
    }
  }

  function showPanel() {
    if (!panelIframe) return;
    panelIframe.classList.add('visible');
    const overlay = document.getElementById(PANEL_OVERLAY_ID);
    if (overlay) overlay.classList.add('visible');
    // 面板显示时重新发送就绪信号（确保 panel.js 能收到）
    setTimeout(() => sendContentReady(), 50);
  }

  function hidePanel() {
    if (!panelIframe) return;
    panelIframe.classList.remove('visible');
    const overlay = document.getElementById(PANEL_OVERLAY_ID);
    if (overlay) overlay.classList.remove('visible');
    // 关闭面板时重置拖动偏移，下次打开居中
    resetDragTransform();
  }

  function resetDragTransform() {
    if (dragState) {
      document.removeEventListener('mousemove', dragState.onMouseMove);
      document.removeEventListener('mouseup', dragState.onMouseUp);
      dragState = null;
    }
    if (panelIframe) {
      // 还原为居中定位
      panelIframe.style.left = '';
      panelIframe.style.top = '';
      panelIframe.style.transform = 'translate(-50%, -50%) scale(0.9)';
    }
    document.body.style.cursor = '';
    document.body.style.userSelect = '';
  }

  // ==================== 面板拖动 ====================

  function startDrag(offsetX, offsetY) {
    if (!panelIframe) return;

    // 获取面板当前左上角在视口中的位置
    const rect = panelIframe.getBoundingClientRect();

    // 从居中对齐 transform 切换到固定 left/top 定位
    panelIframe.style.left = rect.left + 'px';
    panelIframe.style.top = rect.top + 'px';
    panelIframe.style.transform = 'scale(0.9)';

    const onMouseMove = (e) => {
      if (!dragState) return;
      const newLeft = e.clientX - offsetX;
      const newTop = e.clientY - offsetY;
      panelIframe.style.left = newLeft + 'px';
      panelIframe.style.top = newTop + 'px';
      if (panelIframe && panelIframe.contentWindow) {
        panelIframe.contentWindow.postMessage({
          action: 'drag-move',
          left: newLeft,
          top: newTop
        }, '*');
      }
    };

    const onMouseUp = () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
      if (dragState && panelIframe && panelIframe.contentWindow) {
        panelIframe.contentWindow.postMessage({
          action: 'drag-end',
          left: parseFloat(panelIframe.style.left) || 0,
          top: parseFloat(panelIframe.style.top) || 0
        }, '*');
      }
      dragState = null;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    };

    // 清除旧的残留监听（如果有）
    if (dragState) {
      document.removeEventListener('mousemove', dragState.onMouseMove);
      document.removeEventListener('mouseup', dragState.onMouseUp);
    }

    dragState = { offsetX, offsetY, onMouseMove, onMouseUp };

    // 仅监听宿主页面 document（鼠标在屏幕任意位置都能跟踪）
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
    document.body.style.cursor = 'grabbing';
    document.body.style.userSelect = 'none';
  }

  // ==================== 确认对话框 ===================
  function showConfirmDialog(title, message, onConfirm, onCancel) {
    const overlay = document.createElement('div');
    overlay.className = 'ds-confirm-overlay';
    overlay.style.cssText = [
      'position: fixed;',
      'inset: 0;',
      'background: rgba(0,0,0,0.5);',
      'z-index: 2147483648;',
      'display: flex;',
      'align-items: center;',
      'justify-content: center;',
      'animation: dsFadeIn 0.15s ease;'
    ].join('');

    const dialog = document.createElement('div');
    dialog.style.cssText = [
      'background: #fff;',
      'border-radius: 14px;',
      'box-shadow: 0 12px 48px rgba(0,0,0,0.25);',
      'padding: 24px;',
      'max-width: 380px;',
      'width: 90%;',
      'animation: dsScaleIn 0.2s ease;'
    ].join('');

    dialog.innerHTML = [
      '<h3 style="margin:0 0 8px;font-size:16px;font-weight:600;color:#333;">' + escapeHTML(title) + '</h3>',
      '<p style="margin:0 0 20px;font-size:13px;color:#666;line-height:1.6;">' + escapeHTML(message) + '</p>',
      '<div style="display:flex;justify-content:flex-end;gap:8px;">',
        '<button class="ds-confirm-cancel" style="padding:8px 16px;border:1px solid #dadce0;border-radius:8px;background:#fff;color:#333;cursor:pointer;font-size:13px;">取消</button>',
        '<button class="ds-confirm-ok" style="padding:8px 16px;border:none;border-radius:8px;background:#1890ff;color:#fff;cursor:pointer;font-size:13px;">是</button>',
      '</div>'
    ].join('');

    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    const cleanup = () => {
      overlay.remove();
    };

    dialog.querySelector('.ds-confirm-ok').addEventListener('click', () => {
      cleanup();
      if (onConfirm) onConfirm();
    });

    dialog.querySelector('.ds-confirm-cancel').addEventListener('click', () => {
      cleanup();
      if (onCancel) onCancel();
    });

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        cleanup();
        if (onCancel) onCancel();
      }
    });
  }

  function escapeHTML(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // ==================== 统一收藏入口 ====================
  // 所有收藏触发（⭐按钮、快捷键、右键）都用这两个函数

  /**
   * 收藏当前页面对话
   */
  async function bookmarkCurrentPage() {
    // [关键修复] 强制获取实时标题快照，替代旧的 getPageTitle() 路径
    const realTimeTitle = await getTrustedTitle();

    // 传入可靠标题，后面走 background/storage 逻辑
    const url = window.location.href;
    const snippet = getPageSnippet();

    console.log('[DeepSeek-Assistant][bookmarkCurrentPage] 标题来源=getTrustedTitle | title=', realTimeTitle, '| url=', url);

    // ★ 新增：收藏时弹出备注输入框
    const note = prompt('请输入收藏备注（可选）：', '') || '';
    console.log('[DeepSeek-Assistant][bookmarkCurrentPage] 备注 note=', note);

    bookmarkConversation(realTimeTitle, url, snippet, note);
  }

  /**
   * 统一收藏逻辑：优先 background 中转，失败降级直接 storage
   */
  async function bookmarkConversation(title, url, snippet, note) {
    const data = {
      title: title || '未命名对话',
      url: url || window.location.href,
      snippet: snippet || '',
      note: note || '',
      timestamp: Date.now()
    };

    console.log('[DeepSeek-Assistant][bookmarkConversation] 统一收藏入口 | data=', JSON.stringify(data));

    // 方式1：通过 background 中转（更可靠的去重+存储）
    try {
      if (chrome.runtime && chrome.runtime.id) {
        const res = await chrome.runtime.sendMessage({
          action: 'bookmark-conversation',
          data
        });

        if (res && res.success) {
          showToast('\u2B50 已收藏当前对话');
          notifyPanelRefresh();
          return;
        }
        if (res && res.error) {
          showToast('\u26A0\uFE0F ' + res.error);
          return;
        }
      }
    } catch (e) {
      // SW 不可用，降级到直接 storage 操作
      console.warn('[DeepSeek-Assistant] SW unreachable, using direct storage:', e.message);
    }

    // 方式2：降级 — 直接操作 chrome.storage.local
    try {
      const stored = await chrome.storage.local.get(['bookmarks']);
      const bookmarks = stored['bookmarks'] || [];

      const exists = bookmarks.some(b => {
        // URL 不同 = 不同对话（即使标题相同）
        if (b.url && data.url) return b.url === data.url;
        // URL 为空，用标题兜底
        return b.title === data.title;
      });
      if (exists) {
        showToast('\u26A0\uFE0F 该对话已在收藏夹中');
        return;
      }

      bookmarks.unshift({
        ...data,
        id: Date.now().toString() + '_' + Math.random().toString(36).slice(2),
        createdAt: new Date().toISOString()
      });

      await chrome.storage.local.set({ bookmarks });
      showToast('\u2B50 已收藏当前对话');
      notifyPanelRefresh();
    } catch (e) {
      console.error('[DeepSeek-Assistant] Bookmark failed:', e);
      showToast('\u274C 收藏失败，请刷新页面后重试');
    }
  }

  /**
   * 通知 panel iframe 刷新收藏夹列表
   */
  function notifyPanelRefresh() {
    if (panelIframe && panelIframe.contentWindow) {
      try {
        panelIframe.contentWindow.postMessage({ action: 'new-bookmark' }, '*');
      } catch (e) {
        // ignore cross-origin errors
      }
    }
  }

  // ==================== 通知 panel 就绪信号 ====================
  function sendContentReady() {
    if (panelIframe && panelIframe.contentWindow) {
      try {
        panelIframe.contentWindow.postMessage({ action: 'content-ready' }, '*');
      } catch (e) {
        // Panel may not be ready yet - ignore
      }
    }
  }

  // ==================== 抓取侧边栏对话列表 ====================
  async function fetchSidebarConversations() {
    const conversations = [];

    // DOM 就绪检查：确保左侧对话列表容器已存在且非空
    const MAX_DOM_RETRIES = 3;
    const DOM_RETRY_DELAY_MS = 300;
    for (let attempt = 1; attempt <= MAX_DOM_RETRIES; attempt++) {
      // 检查侧边栏容器是否存在且有子元素
      const sidebarAnchor = document.querySelector('a[href*="/chat/"]');
      const sidebarContainer = document.querySelector('[class*="sidebar"]') ||
                               document.querySelector('nav') ||
                               document.querySelector('aside');
      const hasContent = sidebarAnchor !== null ||
                         (sidebarContainer !== null && sidebarContainer.children.length > 0);
      if (hasContent) break;
      if (attempt < MAX_DOM_RETRIES) {
        await new Promise(r => setTimeout(r, DOM_RETRY_DELAY_MS));
      }
    }

    const selectors = [
      'a[href*="/chat/"]',           // ★ 最直接的选择器：DeepSeek 侧边栏对话链接
      '[class*="sidebar"] [class*="conversation"]',
      '[class*="sidebar"] [class*="chat-item"]',
      '[class*="sidebar"] a[href*="/chat/"]',
      'nav a[href*="/chat/"]',
      '[class*="conversation-list"] > *',
      '[class*="chat-list"] > *',
      '[class*="nav"] a[href*="/chat/"]',
      '[class*="SideBar"] a',
      '[class*="sidebar"] li',
      '[data-testid*="conversation"]',
      '[data-testid*="history"] a',
      '[class*="sidebar"] a',
      'aside a[href*="/chat/"]'
    ];

    let items = [];
    for (const selector of selectors) {
      try {
        const found = document.querySelectorAll(selector);
        if (found.length > 0) {
          items = Array.from(found);
          break;
        }
      } catch (e) {
        // continue
      }
    }

    // ★ 如果未找到任何对话项（侧边栏已收起，DOM 被移除），尝试展开侧边栏后重试
    if (items.length === 0) {
      // 查找侧边栏展开/切换按钮
      const toggleSelectors = [
        'button[class*="sidebar"]',
        'button[class*="toggle"]',
        'button[class*="menu"]',
        'button[class*="expand"]',
        'button[aria-label*="sidebar" i]',
        'button[aria-label*="toggle" i]',
        'button[aria-label*="menu" i]',
        'button[aria-label*="expand" i]',
        'button[aria-label*="展开" i]',
        'button[aria-label*="收起" i]',
        '[class*="sidebar-toggle"]',
        '[class*="sidebar-btn"]',
        '[class*="expand-sidebar"]',
        '[class*="open-sidebar"]',
      ];

      let toggleBtn = null;
      for (const sel of toggleSelectors) {
        try {
          const btn = document.querySelector(sel);
          if (btn) {
            toggleBtn = btn;
            break;
          }
        } catch (e) { /* continue */ }
      }

      if (toggleBtn) {
        toggleBtn.click();
        // 等待 DOM 加载完成
        await new Promise(r => setTimeout(r, 500));

        // 重新尝试抓取对话列表
        for (const selector of selectors) {
          try {
            const found = document.querySelectorAll(selector);
            if (found.length > 0) {
              items = Array.from(found);
              break;
            }
          } catch (e) { /* continue */ }
        }
      }

      // 仍然找不到，返回提示信息
      if (items.length === 0) {
        conversations.push({
          title: '💡 请展开左侧边栏后重试',
          url: window.location.href,
          snippet: '侧边栏已收起，无法获取对话列表。请点击左上角的侧边栏展开按钮后再试。',
          timestamp: Date.now()
        });
        return conversations;
      }
    }

    const seen = new Set();
    items.forEach(el => {
      const text = (el.textContent || '').trim();
      const href = el.getAttribute('href') || el.querySelector('a')?.getAttribute('href') || '';

      if (!text || text.length < 2) return;

      const key = text.slice(0, 80);
      if (seen.has(key)) return;
      seen.add(key);

      let timestamp = 0;

      const timeSelectors = [
        '[class*="time"]',
        '[class*="date"]',
        '[class*="timestamp"]',
        '[class*="Time"]',
        '[class*="Date"]',
        '[class*="Timestamp"]',
        'time',
        '[datetime]',
        '[title]',
        '[class*="meta"]'
      ];

      for (const timeSel of timeSelectors) {
        try {
          const timeEl = el.querySelector(timeSel);
          if (timeEl) {
            const timeText = timeEl.textContent?.trim() || '';
            const dateAttr = timeEl.getAttribute('datetime');

            if (dateAttr) {
              const parsed = Date.parse(dateAttr);
              if (!isNaN(parsed) && parsed > 0) {
                timestamp = parsed;
                break;
              }
            }

            if (timeText) {
              const parsedTime = parseTimeText(timeText);
              if (parsedTime > 0) {
                timestamp = parsedTime;
                break;
              }
            }
          }
        } catch (e) {
          // continue
        }
      }

      if (timestamp === 0) {
        const titleAttr = el.getAttribute('title');
        if (titleAttr) {
          const parsed = parseTimeText(titleAttr);
          if (parsed > 0) {
            timestamp = parsed;
          }
        }
      }

      if (timestamp === 0) {
        const parsed = parseTimeText(text);
        if (parsed > 0) {
          timestamp = parsed;
        }
      }

      conversations.push({
        title: text.slice(0, 100),
        url: href.startsWith('http') ? href : (href ? new URL(href, window.location.origin).href : window.location.href),
        snippet: '',
        timestamp
      });
    });

    return conversations;
  }

  function parseTimeText(text) {
    if (!text) return 0;

    const directParse = Date.parse(text);
    if (!isNaN(directParse) && directParse > 0) {
      return directParse;
    }

    const cnDateMatch = text.match(/(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日\s*(\d{1,2})?\s*:?\s*(\d{2})?/);
    if (cnDateMatch) {
      const [, year, month, day, hour, minute] = cnDateMatch;
      return new Date(
        parseInt(year),
        parseInt(month) - 1,
        parseInt(day),
        parseInt(hour || '0'),
        parseInt(minute || '0')
      ).getTime();
    }

    const dateMatch = text.match(/(\d{4})[-\/]\s*(\d{1,2})[-\/]\s*(\d{1,2})/);
    if (dateMatch) {
      const [, year, month, day] = dateMatch;
      return new Date(parseInt(year), parseInt(month) - 1, parseInt(day)).getTime();
    }

    const now = Date.now();
    const hourMatch = text.match(/(\d+)\s*小时前/);
    if (hourMatch) {
      return now - parseInt(hourMatch[1]) * 3600 * 1000;
    }
    const minMatch = text.match(/(\d+)\s*分钟前/);
    if (minMatch) {
      return now - parseInt(minMatch[1]) * 60 * 1000;
    }
    const dayMatch = text.match(/(\d+)\s*天前/);
    if (dayMatch) {
      return now - parseInt(dayMatch[1]) * 86400 * 1000;
    }
    if (text.includes('昨天')) {
      const d = new Date(now);
      d.setDate(d.getDate() - 1);
      d.setHours(0, 0, 0, 0);
      return d.getTime();
    }
    if (text.includes('前天')) {
      const d = new Date(now);
      d.setDate(d.getDate() - 2);
      d.setHours(0, 0, 0, 0);
      return d.getTime();
    }
    if (text.includes('刚刚') || text.includes('几秒')) {
      return now;
    }

    return 0;
  }

  // ==================== 当前对话搜索 ====================
  // 功能边界：只搜索右侧当前对话页面内已渲染的消息内容，不搜索左侧侧边栏

  /**
   * 获取主对话内容容器
   * DeepSeek 布局: DIV.c3ecdb44 包含侧边栏(dc04ec1d) + 工具栏 + 主内容(_7780f2e)
   * 主内容内: ._765a5cd.ds-scroll-area > .ds-virtual-list.ds-virtual-list--printable
   * 侧边栏内: ._6d215eb.ds-scroll-area > ... > a[href*="/chat/"]
   * 返回主对话内容容器，确保搜索不跨入侧边栏
   */
  function getMainConversationContainer() {
    // 策略1: CDP 验证 — 主内容区域 ._7780f2e 包含 ._765a5cd 和虚拟列表
    const mainArea = document.querySelector('._7780f2e');
    if (mainArea && mainArea.querySelectorAll('.ds-message').length >= 1) return mainArea;

    // 策略2: DeepSeek 虚拟列表（可打印的消息列表容器）
    const vl = document.querySelector('[class*="ds-virtual-list"][class*="printable"]');
    if (vl && vl.querySelectorAll('.ds-message').length >= 1) return vl;

    // 策略3: 兼容旧类名 ._765a5cd.ds-scroll-area
    const alt = document.querySelector('[class*="_765a5cd"]');
    if (alt && alt.querySelectorAll('.ds-message').length >= 1) return alt;

    // 策略4: 排除侧边栏后找到包含消息的容器
    const c3 = document.querySelector('.c3ecdb44');
    if (c3) {
      for (const child of c3.children) {
        const cls = (typeof child.className === 'string' ? child.className : '');
        if (/dc04ec1d|a02af2e6|sidebar/i.test(cls)) continue;
        const msgs = child.querySelectorAll('.ds-message');
        if (msgs.length >= 1) return child;
      }
    }

    // 策略5: 回退到 body，排除明显侧边栏
    const sidebar = document.querySelector('[class*="dc04ec1d"], [class*="a02af2e6"], [class*="sidebar"]');
    if (sidebar) {
      const parent = sidebar.parentElement;
      if (parent) {
        for (const child of parent.children) {
          if (child !== sidebar && child.querySelectorAll('.ds-message').length >= 1) {
            return child;
          }
        }
      }
    }

    return document.body;
  }

  /**
   * Bug C: 检查元素是否属于 AI 思考过程节点
   * DeepSeek 思考过程标志:
   *   - 类名: ds-think-content, e1675d8b, _767406f (CDP 验证确认)
   *   - 思考标签文本: SPAN._5255ff8._4d41763 (内容 "已思考（用时 X 秒）")
   *   - 祖先元素属性: aria-label, data-type 等含 thinking/reasoning/thought/思考
   */
  function isThinkingElement(el) {
    let current = el;
    while (current && current !== document.body && current !== document.documentElement) {
      // 1) 检查 className
      const cls = (typeof current.className === 'string' ? current.className : '').toLowerCase();
      const baseCls = (typeof current.className === 'object' && current.className.baseVal
        ? current.className.baseVal : '').toLowerCase();
      const combinedCls = cls + ' ' + baseCls;
      // CDP 验证确认的 DeepSeek 思考内容类名
      if (/ds-think-content|e1675d8b|_767406f|_5255ff8|thinking|reasoning|thought|think|深度思考|推理过程/i.test(combinedCls)) {
        return true;
      }

      // 2) 检查属性: aria-label, data-type, data-reasoning 等
      if (current.getAttribute) {
        for (const attr of ['aria-label', 'data-type', 'data-reasoning', 'data-thinking',
                            'data-testid', 'data-role', 'data-section', 'title']) {
          const val = (current.getAttribute(attr) || '').toLowerCase();
          if (/thinking|reasoning|thought|think|思考|推理|深度思/i.test(val)) return true;
        }
        // 3) 检查属性名称本身（如 data-thinking-container）
        for (const attrName of current.getAttributeNames()) {
          if (/thinking|reasoning|thought|think|深度思考/i.test(attrName.toLowerCase())) return true;
        }
      }

      current = current.parentElement;
    }

    // 4) 文本前缀检测：已思考、深度思考、思考过程 等
    const ownText = (el.textContent || '').trim().slice(0, 30).toLowerCase();
    if (/^(已深度思考|已思考|深度思考|思考过程|推理过程|reasoning|thinking)/i.test(ownText)) return true;

    return false;
  }

  /**
   * Bug D: 从 DOM 元素提取对话 URL
   * 当前对话搜索范围内的元素都属于当前对话，直接返回当前页面 URL
   * （侧边栏元素不会进入此函数，因为 gatherCandidates 已限定在主对话容器内）
   */
  function findConversationLink(el) {
    // 策略1: 向上查找最近 <a> 标签的 href（适用于侧边栏链接等）
    const link = el.closest('a[href]');
    if (link) {
      const href = link.getAttribute('href');
      if (href && href !== '#' && !href.startsWith('javascript:')) {
        return href.startsWith('http') ? href : window.location.origin + href;
      }
    }

    // 策略2: 祖先元素的 data-conversation-id / data-chat-id 等属性
    let current = el;
    while (current && current !== document.body && current !== document.documentElement) {
      for (const attr of ['data-conversation-id', 'data-chat-id', 'data-thread-id', 'data-conv-id']) {
        const val = current.getAttribute && current.getAttribute(attr);
        if (val && val.length >= 4) {
          const pathParts = window.location.pathname.split('/').filter(Boolean);
          if (pathParts.length > 0) {
            pathParts[pathParts.length - 1] = val;
          } else {
            pathParts.push('a', 'chat', 's', val);
          }
          return window.location.origin + '/' + pathParts.join('/');
        }
      }
      current = current.parentElement;
    }

    // 策略3: 从当前页面 URL 路径提取对话 ID，构建干净 URL
    // CDP 验证：URL 格式为 /a/chat/s/{uuid} 或 /c/{uuid}
    const pn = window.location.pathname;
    const parts = pn.split('/').filter(Boolean);
    // 匹配 /a/chat/s/{uuid} 或 /c/{uuid} 格式
    const convMatch = pn.match(/\/(?:a\/chat\/s|c)\/([a-zA-Z0-9_-]+)/);
    if (convMatch && convMatch[1] && convMatch[1].length >= 4) {
      return window.location.origin + pn; // 干净 URL (pathname only, 无 query/hash)
    }

    // 策略4: 最后兜底 — 构建 origin + pathname（不含 query 和 hash）
    return window.location.origin + window.location.pathname;
  }

  function searchCurrentPage(query) {
    // ★ 动态注入搜索高亮样式，确保不会被页面 CSS 覆盖
    if (!document.getElementById('ds-search-highlight-style')) {
      const style = document.createElement('style');
      style.id = 'ds-search-highlight-style';
      style.textContent = 'mark, .highlight { background-color: #ff4d4f !important; color: #ffffff !important; }';
      document.head.appendChild(style);
    }

    if (!query) return [];
    const lowerQuery = query.toLowerCase();

    // === 搜索范围限定为主对话容器（CDP 验证：._7780f2e）===
    const container = getMainConversationContainer();
    if (!container) return [];

    // === CDP 诊断返回的真实 class 名称，合并所有选择器结果 ===
    const selectors = [
      '.ds-message',                        // DeepSeek 消息容器（CDP: ds-message _63c77b1）
      '.ds-markdown',                       // DeepSeek markdown 消息体（CDP verified）
      '.ds-markdown-paragraph',             // markdown 段落（CDP: 96个跨4条消息）
      '.ds-assistant-message-main-content', // AI 回复消息主内容（CDP verified）
    ];

    // 阶段1: 在主对话容器内收集所有匹配元素，用 Set 以 DOM 引用去重
    const seenElements = new Set();
    const allCandidates = [];
    for (const selector of selectors) {
      try {
        const found = container.querySelectorAll(selector);
        for (const el of found) {
          if (!seenElements.has(el)) {
            seenElements.add(el);
            allCandidates.push(el);
          }
        }
      } catch (e) { /* skip invalid selectors */ }
    }

    if (allCandidates.length === 0) {
      // 全文退化
      const containerText = container.textContent || '';
      if (containerText.toLowerCase().includes(lowerQuery)) {
        return [{
          title: '页面内容匹配',
          type: '全文',
          snippet: getContextSnippet(containerText, lowerQuery),
          url: findConversationLink(container) || window.location.origin + window.location.pathname
        }];
      }
      return [];
    }

    // 阶段2: 祖先过滤 — 若元素A包含元素B（A.contains(B)），删除A，保留B
    const ancestorIdx = new Set();
    for (let i = 0; i < allCandidates.length; i++) {
      for (let j = i + 1; j < allCandidates.length; j++) {
        try {
          if (allCandidates[i].contains(allCandidates[j])) {
            ancestorIdx.add(i);
          } else if (allCandidates[j].contains(allCandidates[i])) {
            ancestorIdx.add(j);
          }
        } catch (e) { /* cross-document nodes */ }
      }
    }
    const filtered = allCandidates.filter((_, idx) => !ancestorIdx.has(idx));

    // 阶段3: 遍历 → 过滤思考过程 → 文本去重 → 构建结果
    // 使用 filteredIdx 记录元素在 filtered 数组中的位置，供 scrollToResult 精确定位
    const seenTexts = new Set();
    const results = [];
    filtered.forEach((el, filteredIdx) => {
      const text = (el.textContent || '').trim();
      if (!text || text.length < 2) return;

      // 排除 AI 思考过程节点
      if (isThinkingElement(el)) return;

      if (text.toLowerCase().includes(lowerQuery)) {
        // 文本去重: "前100字符 + 长度" 联合指纹
        const dedupKey = text.slice(0, 100).toLowerCase().replace(/\s+/g, ' ') + '|' + text.length;
        if (seenTexts.has(dedupKey)) return;
        seenTexts.add(dedupKey);

        // 推断消息类型
        let type = '内容';
        const clsName = (typeof el.className === 'string' ? el.className : '').toLowerCase();
        const parent = el.parentElement;
        const parentCls = (parent && typeof parent.className === 'string'
          ? parent.className : '').toLowerCase();
        const combinedCls = clsName + ' ' + parentCls;

        // CDP 验证: 用户消息有 class d29f3d7d
        if (/d29f3d7d|user|human/i.test(combinedCls)) {
          type = '用户消息';
        } else if (/ds-markdown|ds-assistant|_74c0879|dbe8cf4a/i.test(combinedCls)) {
          type = 'AI回复';
        }

        // 提取标题
        let title = '';
        const heading = el.querySelector('h1, h2, h3, h4, h5, h6, strong, [class*="title"]');
        if (heading) {
          title = heading.textContent.trim().slice(0, 80);
        }
        if (!title) {
          title = text.replace(/\s+/g, ' ').slice(0, 60).trim();
          if (text.length > 60) title += '...';
        }

        // 提取对话链接（CDP 验证：无法从 DOM 提取，从 URL 解析）
        const url = findConversationLink(el);

        results.push({
          title,
          type,
          snippet: getContextSnippet(text, lowerQuery),
          url: '',  // 改为空字符串，点击后走 scroll-to-result 逻辑，不再打开新标签页
          index: filteredIdx,  // 使用 filtered 数组下标，与 scrollToResult 对齐
          timestamp: results.length
        });
      }
    });

    return results;
  }

  function getContextSnippet(text, lowerQuery) {
    const index = text.toLowerCase().indexOf(lowerQuery);
    if (index === -1) return text.slice(0, 200);

    const start = Math.max(0, index - 60);
    const end = Math.min(text.length, index + lowerQuery.length + 80);
    let snippet = text.slice(start, end);
    if (start > 0) snippet = '...' + snippet;
    if (end < text.length) snippet = snippet + '...';
    return snippet;
  }

  function scrollToResult(index) {
    // 重建与 searchCurrentPage 完全相同的 filtered 数组，用 index 正确定位元素
    const container = getMainConversationContainer();
    if (!container) return;

    const selectors = [
      '.ds-message',
      '.ds-markdown',
      '.ds-markdown-paragraph',
      '.ds-assistant-message-main-content',
    ];

    // 收集 + DOM 去重
    const seen = new Set();
    const msgs = [];
    for (const sel of selectors) {
      try {
        container.querySelectorAll(sel).forEach(el => {
          if (!seen.has(el)) { seen.add(el); msgs.push(el); }
        });
      } catch (e) { /* skip */ }
    }

    // 祖先过滤（与 searchCurrentPage 完全一致）
    const ancestorIdx = new Set();
    for (let i = 0; i < msgs.length; i++) {
      for (let j = i + 1; j < msgs.length; j++) {
        try {
          if (msgs[i].contains(msgs[j])) ancestorIdx.add(i);
          else if (msgs[j].contains(msgs[i])) ancestorIdx.add(j);
        } catch (e) { /* cross-document */ }
      }
    }
    const filtered = msgs.filter((_, i) => !ancestorIdx.has(i));

    // index 是 filtered 数组下标，与 searchCurrentPage 的 filteredIdx 对齐
    if (filtered.length > index) {
      const el = filtered[index];

      // 滚动到目标位置
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });

      // 红框高亮闪烁：3 次闪烁（6 次状态切换），每次 350ms
      const BLINK_INTERVAL = 350; // ms，在 0.3-0.4 秒范围内
      const MAX_TOGGLES = 6;     // 6 次切换 = 3 次完整闪烁

      // 保存原始样式值，闪烁结束后恢复
      const origOutline = el.style.outline;
      const origOutlineOffset = el.style.outlineOffset;
      const origBoxShadow = el.style.boxShadow;
      const origTransition = el.style.transition;

      el.style.transition = 'outline 0.15s ease, box-shadow 0.15s ease';

      let toggle = 0;
      const blinkTimer = setInterval(() => {
        if (toggle % 2 === 0) {
          // ON: 红框 + 红光晕
          el.style.outline = '3px solid #ff4d4f';
          el.style.outlineOffset = '3px';
          el.style.boxShadow = '0 0 14px rgba(255, 77, 79, 0.55)';
        } else {
          // OFF: 恢复原始
          el.style.outline = origOutline || '';
          el.style.outlineOffset = origOutlineOffset || '';
          el.style.boxShadow = origBoxShadow || '';
        }
        toggle++;
        if (toggle >= MAX_TOGGLES) {
          clearInterval(blinkTimer);
          // 最终恢复原始样式
          el.style.outline = origOutline || '';
          el.style.outlineOffset = origOutlineOffset || '';
          el.style.boxShadow = origBoxShadow || '';
          el.style.transition = origTransition || '';
        }
      }, BLINK_INTERVAL);
    }
  }

  // ==================== 页面标题与摘要 ====================
  /**
   * @deprecated 请使用 getTrustedTitle() 替代。
   * bookmarkCurrentPage 已迁移至 getTrustedTitle()，此函数仅保留供其他旧调用点兼容。
   * 已彻底移除侧边栏 DOM 遍历逻辑（原 fetchSidebarConversations 中的 sidebar 扫描与此无关）。
   */
  function getPageTitle() {
    // 仅从 document.title 获取标题，不从侧边栏提取
    if (document.title && document.title.trim()) {
      return document.title.trim().slice(0, 100);
    }
    return '未命名对话';
  }

  /**
   * 可信标题获取函数 —— 收藏时的核心修复
   * 专为 bookmarkCurrentPage 设计，取代 getPageTitle() 路径：
   *   1. 强制从 document.title 获取，杜绝侧边栏 DOM 干扰
   *   2. 清洗无用后缀（如 " - DeepSeek"）
   *   3. 空标题时降级到 URL pathname，但禁止从侧边栏（nav, aside）回退
   *
   * [调试] 输出 document.title 原始值和清洗过程，便于排查数据来源
   */
  async function getTrustedTitle() {
    // 1. 先直接读取当前 document.title
    const rawTitle = (document.title || '').trim();
    console.log('[DeepSeek-Assistant][getTrustedTitle] 原始 document.title =', JSON.stringify(rawTitle));

    let currentTitle = rawTitle;

    // 2. 清洗常见无用后缀
    currentTitle = currentTitle.replace(/\s*[-–—|]\s*DeepSeek.*$/i, '').trim();
    console.log('[DeepSeek-Assistant][getTrustedTitle] 清洗后 title =', JSON.stringify(currentTitle));

    // 3. 空标题降级到 URL pathname (绝不从侧边栏 DOM 查找)
    if (!currentTitle) {
      const pathParts = window.location.pathname.split('/').filter(Boolean);
      currentTitle = pathParts[pathParts.length - 1] || '未命名对话';
      console.log('[DeepSeek-Assistant][getTrustedTitle] 降级到 pathname =', JSON.stringify(currentTitle));
    }

    const finalTitle = currentTitle.slice(0, 100);
    console.log('[DeepSeek-Assistant][getTrustedTitle] 最终返回 title =', JSON.stringify(finalTitle));
    return finalTitle;
  }

  function getPageSnippet() {
    const selectors = [
      '[class*="message"]',
      '[class*="chat"] p',
      'article p'
    ];
    for (const sel of selectors) {
      try {
        const el = document.querySelector(sel);
        if (el && el.textContent.trim()) {
          return el.textContent.trim().slice(0, 150);
        }
      } catch (e) {
        // continue
      }
    }
    return '';
  }

  // ==================== Toast 提示 ====================
  function showToast(message) {
    let container = document.getElementById('ds-assistant-toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'ds-assistant-toast-container';
      container.style.cssText = [
        'position: fixed;',
        'top: 20px;',
        'left: 50%;',
        'transform: translateX(-50%);',
        'z-index: 99999;',
        'display: flex;',
        'flex-direction: column;',
        'align-items: center;',
        'gap: 8px;',
        'pointer-events: none;'
      ].join('');
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.textContent = message;
    toast.style.cssText = [
      'background: rgba(0,0,0,0.8);',
      'color: #fff;',
      'padding: 10px 20px;',
      'border-radius: 8px;',
      'font-size: 14px;',
      'pointer-events: auto;',
      'animation: ds-toast-in 0.3s ease;'
    ].join('');
    container.appendChild(toast);

    if (!document.getElementById('ds-toast-style')) {
      const style = document.createElement('style');
      style.id = 'ds-toast-style';
      style.textContent = [
        '@keyframes ds-toast-in {',
        '  from { opacity: 0; transform: translateY(-10px); }',
        '  to { opacity: 1; transform: translateY(0); }',
        '}'
      ].join('\n');
      document.head.appendChild(style);
    }

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s';
      setTimeout(() => toast.remove(), 300);
    }, 2500);
  }

  // ==================== 关于覆盖层 ====================

  const ABOUT_OVERLAY_ID = 'ds-about-overlay';
  let aboutOverlay = null;

  function openAboutOverlay() {
    // 防重复
    if (document.getElementById(ABOUT_OVERLAY_ID)) return;

    // 创建遮罩
    const overlay = document.createElement('div');
    overlay.id = ABOUT_OVERLAY_ID;
    overlay.style.cssText = [
      'position: fixed;',
      'top: 0;',
      'left: 0;',
      'width: 100vw;',
      'height: 100vh;',
      'background: rgba(0,0,0,0.4);',
      'z-index: 2147483646;',
      'display: flex;',
      'align-items: center;',
      'justify-content: center;'
    ].join('');

    // 创建弹窗容器
    const dialog = document.createElement('div');
    dialog.style.cssText = [
      'width: 480px;',
      'max-width: 90vw;',
      'height: 80vh;',
      'max-height: 88vh;',
      'background: #ffffff;',
      'border-radius: 14px;',
      'box-shadow: 0 12px 48px rgba(0,0,0,0.25);',
      'overflow: hidden;',
      'display: flex;',
      'flex-direction: column;'
    ].join('');

    // 适配深色模式
    if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
      dialog.style.background = '#1e1e1e';
    }

    // 创建 iframe
    const iframe = document.createElement('iframe');
    iframe.src = chrome.runtime.getURL('about.html');
    iframe.style.cssText = 'width:100%; height:100%; border:none;';

    dialog.appendChild(iframe);
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);
    aboutOverlay = overlay;

    // 点击遮罩关闭
    overlay.addEventListener('click', function(e) {
      if (e.target === overlay) {
        closeAboutOverlay();
      }
    });

    // Esc 关闭
    const escHandler = function(e) {
      if (e.key === 'Escape') {
        closeAboutOverlay();
        document.removeEventListener('keydown', escHandler);
      }
    };
    document.addEventListener('keydown', escHandler);
  }

  function closeAboutOverlay() {
    const el = document.getElementById(ABOUT_OVERLAY_ID);
    if (el) {
      el.remove();
      aboutOverlay = null;
    }
  }

  // ==================== 消息级收藏系统 ====================

  function initMessageBookmarkSystem() {
    injectMessageBookmarkStyles();
    // 扫描已存在的消息
    scanExistingMessagesForBookmark();
    // 监听动态加载的新消息
    startMessageBookmarkObserver();
  }

  function injectMessageBookmarkStyles() {
    if (document.getElementById('ds-msg-bookmark-style')) return;
    const style = document.createElement('style');
    style.id = 'ds-msg-bookmark-style';
    style.textContent = `
.ds-msg-bookmark-btn {
  opacity: 0;
  transition: opacity 0.2s ease, color 0.2s ease;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border: none;
  border-radius: 6px;
  background: transparent;
  font-size: 14px;
  line-height: 1;
  padding: 0;
  position: absolute;
  top: 8px;
  right: 8px;
  z-index: 10;
  color: #999;
}
.ds-message:hover .ds-msg-bookmark-btn,
.ds-assistant-message-main-content:hover .ds-msg-bookmark-btn {
  opacity: 1;
}
.ds-msg-bookmark-btn:hover {
  background: rgba(0,0,0,0.06);
  color: #f5a623;
}
.ds-msg-bookmark-btn.bookmarked {
  opacity: 1;
  color: #f5a623 !important;
}
`;
    document.head.appendChild(style);
  }

  function scanExistingMessagesForBookmark() {
    const messages = document.querySelectorAll('.ds-message');
    messages.forEach(injectBookmarkButton);
  }

  function startMessageBookmarkObserver() {
    const targetNode = document.querySelector('._7780f2e')
      || document.querySelector('[class*="ds-virtual-list"][class*="printable"]')
      || document.querySelector('[class*="_765a5cd"]')
      || document.body;

    const observer = new MutationObserver(function(mutations) {
      var needsScan = false;
      for (var i = 0; i < mutations.length; i++) {
        if (mutations[i].type === 'childList' && mutations[i].addedNodes.length > 0) {
          needsScan = true;
          break;
        }
      }
      if (needsScan) {
        requestAnimationFrame(function() {
          var newMessages = targetNode.querySelectorAll('.ds-message:not([data-bookmark-injected])');
          for (var j = 0; j < newMessages.length; j++) {
            injectBookmarkButton(newMessages[j]);
          }
        });
      }
    });

    observer.observe(targetNode, { childList: true, subtree: true });
  }

  function injectBookmarkButton(messageEl) {
    if (messageEl.getAttribute('data-bookmark-injected') === 'true') return;
    messageEl.setAttribute('data-bookmark-injected', 'true');

    // 确保消息容器有定位上下文
    if (window.getComputedStyle(messageEl).position === 'static') {
      messageEl.style.position = 'relative';
    }

    var btn = document.createElement('button');
    btn.className = 'ds-msg-bookmark-btn';
    btn.textContent = '\u2B50';
    btn.title = '收藏此消息';

    btn.addEventListener('click', async function(e) {
      e.stopPropagation();
      e.preventDefault();
      await handleMessageBookmark(messageEl, btn);
    });

    messageEl.appendChild(btn);

    // 也向AI回答内容区域（.ds-assistant-message-main-content）注入底部收藏按钮
    var aiContent = messageEl.querySelector('.ds-assistant-message-main-content');
    if (aiContent) {
      if (window.getComputedStyle(aiContent).position === 'static') {
        aiContent.style.position = 'relative';
      }
      var aiBtn = document.createElement('button');
      aiBtn.className = 'ds-msg-bookmark-btn';
      aiBtn.textContent = '\u2B50';
      aiBtn.title = '\u6536\u85CF\u6B64\u6D88\u606F';
      aiBtn.style.top = 'auto';
      aiBtn.style.bottom = '8px';

      aiBtn.addEventListener('click', async function(e) {
        e.stopPropagation();
        e.preventDefault();
        await handleMessageBookmark(messageEl, aiBtn);
      });

      aiContent.appendChild(aiBtn);
    }

    // 异步检查此消息是否已收藏
    checkBookmarkStatus(messageEl, btn);
  }

  async function checkBookmarkStatus(messageEl, btn) {
    try {
      var contentText = (messageEl.textContent || '').trim().slice(0, 500);
      var messageRole = detectMessageRole(messageEl);
      var stored = await chrome.storage.local.get(['messageBookmarks']);
      var bookmarks = stored['messageBookmarks'] || [];
      var found = bookmarks.some(function(b) {
        return b.messageRole === messageRole && b.contentText === contentText;
      });
      if (found) {
        btn.classList.add('bookmarked');
        btn.title = '已收藏';
      }
    } catch (e) {
      // ignore
    }
  }

  function detectMessageRole(messageEl) {
    // 只检查消息元素内部是否包含 .ds-markdown 类名
    // AI消息必定包含 .ds-markdown（DeepSeek markdown 渲染独占区域）
    // 用户消息不含 .ds-markdown
    if (messageEl.querySelector('.ds-markdown, [class*="ds-markdown"]')) {
      return 'AI';
    }
    return '\u7528\u6237';
  }

  async function handleMessageBookmark(messageEl, btn) {
    btn.disabled = true;
    try {
    // 确定消息角色（多策略降级）
    var messageRole = detectMessageRole(messageEl);

    // 提取完整内容
    var contentHTML = messageEl.innerHTML;
    var contentText = (messageEl.textContent || '').trim();

    // ★ 查找消息的唯一键 data-virtual-list-item-key（用于精准定位）
    var virtualContainer = messageEl.closest('[data-virtual-list-item-key]');
    var messageKey = virtualContainer ? virtualContainer.getAttribute('data-virtual-list-item-key') : '';

    // ★ 从 URL 提取对话 sessionId
    var sessionMatch = window.location.pathname.match(/\/a\/chat\/s\/([a-zA-Z0-9_-]+)/);
    var sessionId = sessionMatch ? sessionMatch[1] : '';

    // 获取对话标题（复用受保护的 getTrustedTitle）
    var conversationTitle = await getTrustedTitle();

    var messageId = Date.now().toString() + '_' + Math.random().toString(36).slice(2, 8);
    var baseUrl = window.location.href.split('#')[0];

    // ★ 构建增强版 sharedLink：包含 messageKey 和 sessionId，用于精准定位
    var sharedLink = baseUrl + '#ds-msg=' + encodeURIComponent(messageId);
    if (messageKey) {
      sharedLink += '&msg-key=' + encodeURIComponent(messageKey);
    }
    if (sessionId) {
      sharedLink += '&session=' + encodeURIComponent(sessionId);
    }

    var data = {
      id: messageId,
      messageKey: messageKey,
      sessionId: sessionId,
      messageRole: messageRole,
      contentHTML: contentHTML,
      contentText: contentText.slice(0, 500),
      conversationTitle: conversationTitle,
      url: baseUrl,
      sharedLink: sharedLink,
      timestamp: Date.now(),
      createdAt: new Date().toISOString()
    };

    // 通过 chrome.storage.local 直接存储
    // contentHTML 可能过大（DeepSeek AI 消息含大量 markdown/代码），截断后存储以防存储溢出
    var safeContentHTML = contentHTML.length > 3000 ? contentHTML.slice(0, 3000) : contentHTML;
    data.contentHTML = safeContentHTML;

    try {
      var stored = await chrome.storage.local.get(['messageBookmarks']);
      var bookmarks = stored['messageBookmarks'] || [];

      // 去重检查：messageRole + contentText 组合键（不受截断影响，比 HTML 更精确）
      var contentTextTruncated = contentText.slice(0, 500);
      var exists = bookmarks.some(function(b) {
        return b.messageRole === messageRole && b.contentText === contentTextTruncated;
      });
      if (exists) {
        showToast('\u26A0\uFE0F \u6B64\u6D88\u606F\u5DF2\u5728\u6536\u85CF\u5939\u4E2D');
        btn.classList.add('bookmarked');
        btn.title = '已收藏';
        return;
      }

      bookmarks.unshift(data);
      await chrome.storage.local.set({ messageBookmarks: bookmarks });
      btn.classList.add('bookmarked');
      btn.title = '已收藏';
      showToast('\u2B50 \u5DF2\u6536\u85CF\u6B64\u6D88\u606F');
      chrome.runtime.sendMessage({ action: 'bookmark-updated' }).catch(function(e) {
        if (e && e.message && e.message.indexOf('Extension context invalidated') !== -1) {
          console.warn('[DeepSeek-Assistant] 扩展上下文失效，操作已取消。请刷新页面后重试。');
        }
      });
    } catch (e) {
      console.error('[DeepSeek-Assistant] Message bookmark failed:', e);
      // 检测到扩展上下文失效时，静默处理并跳过降级尝试
      if (e && e.message && e.message.indexOf('Extension context invalidated') !== -1) {
        console.warn('[DeepSeek-Assistant] 扩展状态已变更，请刷新页面后重试。');
        return;
      }
      // 如果因数据过大失败，尝试仅存纯文本版本
      try {
        data.contentHTML = '';
        var stored2 = await chrome.storage.local.get(['messageBookmarks']);
        var bookmarks2 = stored2['messageBookmarks'] || [];
        var exists2 = bookmarks2.some(function(b) { return b.contentText === data.contentText; });
        if (!exists2) {
          bookmarks2.unshift(data);
          await chrome.storage.local.set({ messageBookmarks: bookmarks2 });
          btn.classList.add('bookmarked');
          btn.title = '已收藏';
          showToast('\u2B50 \u5DF2\u6536\u85CF\u6B64\u6D88\u606F');
          chrome.runtime.sendMessage({ action: 'bookmark-updated' }).catch(function(e) {
            if (e && e.message && e.message.indexOf('Extension context invalidated') !== -1) {
              console.warn('[DeepSeek-Assistant] 扩展上下文失效，操作已取消。请刷新页面后重试。');
            }
          });
          return;
        } else {
          showToast('\u26A0\uFE0F \u6B64\u6D88\u606F\u5DF2\u5728\u6536\u85CF\u5939\u4E2D');
          return;
        }
      } catch (e2) {
        console.error('[DeepSeek-Assistant] Message bookmark fallback also failed:', e2);
        if (e2 && e2.message && e2.message.indexOf('Extension context invalidated') !== -1) {
          console.warn('[DeepSeek-Assistant] 扩展状态已变更，请刷新页面后重试。');
          return;
        }
      }
      showToast('\u274C \u6D88\u606F\u6536\u85CF\u5931\u8D25');
    }
    } finally {
      btn.disabled = false;
    }
  }

  // ==================== 消息收藏跳转定位 ====================

  function checkMessageScrollHash() {
    // 立即捕获 hash（防止 SPA 在异步回调前清除）
    var hash = window.location.hash;
    if (!hash || hash.indexOf('ds-msg=') === -1) return;
    var messageIdRaw = hash.match(/ds-msg=([^&]+)/);
    if (!messageIdRaw) return;
    var messageId = decodeURIComponent(messageIdRaw[1]);
    // 安全备份到闭包变量，防止 SPA 清除 hash 后丢失
    var capturedId = messageId;

    console.log('[DeepSeek-Assistant][scroll-hash] 检测到消息跳转请求, messageId=', messageId);

    // 优先直接从 chrome.storage.local 读取 messageBookmarks（避免 sendMessage 引发的上下文错误）
    try {
      chrome.storage.local.get(['messageBookmarks'], function (result) {
        // 检查 chrome.runtime.lastError（扩展上下文失效等情况）
        if (chrome.runtime.lastError) {
          var errMsg = (chrome.runtime.lastError.message || '');
          console.warn('[DeepSeek-Assistant][scroll-hash] storage 读取失败:', errMsg);
          if (errMsg.indexOf('Extension context invalidated') !== -1) {
            console.warn('[DeepSeek-Assistant] 扩展状态已变更，请刷新页面后重试。');
            return;
          }
          // 其他 storage 错误静默处理，不展示 toast
          return;
        }

        var bookmarks = result.messageBookmarks || [];
        var target = null;
        for (var i = 0; i < bookmarks.length; i++) {
          if (bookmarks[i].id === capturedId) {
            target = bookmarks[i];
            break;
          }
        }

        if (!target) {
          console.warn('[DeepSeek-Assistant][scroll-hash] 未找到匹配的消息记录');
          showToast('⚠️ 未找到该收藏消息，可能已被删除');
          return;
        }

        console.log('[DeepSeek-Assistant][scroll-hash] 找到目标消息, role=', target.messageRole, ', text前50字=', (target.contentText || '').slice(0, 50));

        // 优先使用 sharedLink 中的定位信息：若当前页面 URL 基址与收藏时不匹配，跳转到共享链接
        if (target.sharedLink) {
          var targetBaseUrl = target.sharedLink.split('#')[0];
          var currentBaseUrl = window.location.href.split('#')[0];
          if (targetBaseUrl !== currentBaseUrl) {
            console.log('[DeepSeek-Assistant][scroll-hash] 页面不匹配，跳转到 sharedLink:', target.sharedLink);
            window.location.href = target.sharedLink;
            return;
          }
        }

        // 开始轮询等待 DOM 中出现匹配的消息元素
        waitForMessageElement(target, 0);
      });
    } catch (e) {
      // chrome.storage API 完全不可用（极端情况）
      console.warn('[DeepSeek-Assistant][scroll-hash] storage API 不可用:', e.message);
      if (e.message && e.message.indexOf('Extension context invalidated') !== -1) {
        console.warn('[DeepSeek-Assistant] 扩展状态已变更，请刷新页面后重试。');
      }
    }
  }

  function waitForMessageElement(target, attempt) {
    var MAX_ATTEMPTS = 25;      // 增加轮询次数（25次 × 800ms = 20秒）
    var POLL_INTERVAL_MS = 800;

    if (attempt >= MAX_ATTEMPTS) {
      console.info('[DeepSeek-Assistant][scroll-hash] 超时：消息DOM未出现在页面中');
      // 降级：从侧边栏获取当前对话链接并直接打开，触发完整历史加载
      var convLink = document.querySelector('a[href*="/chat/"]');
      if (convLink) {
        var href = convLink.getAttribute('href');
        var fullUrl = href && href.startsWith('http') ? href : (window.location.origin + (href || window.location.pathname));
        showToast('\u{1F4CD} 消息较远，已为您打开对应对话。');
        setTimeout(function () {
          window.location.href = fullUrl;
        }, 1500);
      } else {
        showToast('\u{1F4CD} 收藏的消息较远，已为您定位到对话底部，请上滑加载更多。');
      }
      return;
    }

    var el = findMessageElement(target.contentText, target.messageRole);
    if (el) {
      console.log('[DeepSeek-Assistant][scroll-hash] 找到匹配DOM元素, 滚动并高亮');
      scrollToAndHighlight(el);
      return;
    }

    // 每次轮询主动向上滚动，触发 DeepSeek 虚拟滚动加载更早的消息
    var scrollContainer = document.querySelector('._765a5cd')
      || document.querySelector('[class*="ds-scroll-area"]')
      || document.querySelector('._7780f2e');

    if (scrollContainer && scrollContainer.scrollHeight > scrollContainer.clientHeight) {
      // 大幅上滚以触发虚拟列表向上加载
      scrollContainer.scrollTop = Math.max(0, scrollContainer.scrollTop - 1200);
    } else {
      // 容器不可用时回退到 findScrollableContainer 或 window
      var fallback = findScrollableContainer();
      if (fallback && fallback !== window) {
        fallback.scrollTop = Math.max(0, fallback.scrollTop - 1200);
      } else {
        window.scrollTo(0, Math.max(0, window.scrollY - 1200));
      }
    }

    setTimeout(function () {
      waitForMessageElement(target, attempt + 1);
    }, POLL_INTERVAL_MS);
  }

  function findMessageElement(contentText, messageRole) {
    var messages = document.querySelectorAll('.ds-message');
    var searchText = (contentText || '').trim().slice(0, 200);

    if (!searchText) return null;

    for (var i = 0; i < messages.length; i++) {
      var el = messages[i];
      var elText = (el.textContent || '').trim();

      // 检查角色是否匹配
      var elRole = detectMessageRole(el);
      if (elRole !== messageRole) continue;

      // 检查文本内容是否包含存储的消息文本（双向子串匹配）
      if (elText.indexOf(searchText) !== -1) {
        return el;
      }
      // 如果消息文本较长，用前100字符反查
      if (searchText.length >= 100 && elText.indexOf(searchText.slice(0, 100)) !== -1) {
        return el;
      }
    }

    return null;
  }

  function findScrollableContainer() {
    // DeepSeek 特定容器优先（按可信度排序）
    var deepseekSelectors = [
      '._765a5cd',                          // ds-scroll-area（DeepSeek 消息滚动容器）
      '[class*="ds-scroll-area"]',
      '._7780f2e',                          // 主内容区域
      '[class*="chat-scroll"]',
      '[class*="conversation-content"]',
      '[class*="chat-content"]',
      '[class*="message-list"]',
      '[class*="chat-messages"]',
      'main',
      '[role="main"]'
    ];
    for (var i = 0; i < deepseekSelectors.length; i++) {
      var el = document.querySelector(deepseekSelectors[i]);
      if (el && el.scrollHeight > el.clientHeight) return el;
    }
    // 回退：查找任何包含 .ds-message 的可滚动父元素
    var messages = document.querySelectorAll('.ds-message');
    if (messages.length > 0) {
      var parent = messages[0].parentElement;
      while (parent && parent !== document.body) {
        var cs = window.getComputedStyle(parent);
        if ((cs.overflowY === 'auto' || cs.overflowY === 'scroll') && parent.scrollHeight > parent.clientHeight) {
          return parent;
        }
        parent = parent.parentElement;
      }
    }
    // 最终降级：直接使用 window
    return window;
  }

  function scrollToAndHighlight(el) {
    // 1. 保存原始 scroll-behavior 并禁用平滑滚动
    var origScrollBehavior = document.documentElement.style.scrollBehavior;
    document.documentElement.style.scrollBehavior = 'auto';

    // 2. 用户交互中断标志 —— 一旦用户手动操作，立即停止所有自动行为
    var interrupted = false;
    var interruptHandler = function () {
      interrupted = true;
    };
    document.addEventListener('wheel', interruptHandler, { once: true, passive: true });
    document.addEventListener('touchstart', interruptHandler, { once: true, passive: true });
    document.addEventListener('keydown', interruptHandler, { once: true });

    // 3. 滚动到目标 —— 整个流程中只调用一次 scrollIntoView
    el.scrollIntoView({ behavior: 'auto', block: 'center' });

    // 4. 短暂延迟后恢复 scroll-behavior，确保 auto 滚动已渲染
    setTimeout(function () {
      document.documentElement.style.scrollBehavior = origScrollBehavior;
    }, 60);

    // 5. 如果用户在自动滚动完成前已中断，跳过闪烁动画
    if (interrupted) return;

    // 6. 红框闪烁高亮（每次循环前检查中断标志）
    var BLINK_INTERVAL = 350;
    var MAX_TOGGLES = 6;

    var origOutline = el.style.outline;
    var origOutlineOffset = el.style.outlineOffset;
    var origBoxShadow = el.style.boxShadow;
    var origTransition = el.style.transition;

    el.style.transition = 'outline 0.15s ease, box-shadow 0.15s ease';

    var toggle = 0;
    var blinkTimer = setInterval(function () {
      if (interrupted) {
        clearInterval(blinkTimer);
        el.style.outline = origOutline || '';
        el.style.outlineOffset = origOutlineOffset || '';
        el.style.boxShadow = origBoxShadow || '';
        el.style.transition = origTransition || '';
        return;
      }

      if (toggle % 2 === 0) {
        el.style.outline = '3px solid #ff4d4f';
        el.style.outlineOffset = '3px';
        el.style.boxShadow = '0 0 14px rgba(255, 77, 79, 0.55)';
      } else {
        el.style.outline = origOutline || '';
        el.style.outlineOffset = origOutlineOffset || '';
        el.style.boxShadow = origBoxShadow || '';
      }
      toggle++;
      if (toggle >= MAX_TOGGLES) {
        clearInterval(blinkTimer);
        el.style.outline = origOutline || '';
        el.style.outlineOffset = origOutlineOffset || '';
        el.style.boxShadow = origBoxShadow || '';
        el.style.transition = origTransition || '';
        showToast('📍 已定位到收藏消息');
      }
    }, BLINK_INTERVAL);
  }

  // ==================== 启动 ====================
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();