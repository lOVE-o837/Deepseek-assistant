// ============================================================
// panel.js — DeepSeek助手 主面板逻辑
// 增强版主题替换系统：6套预设 + 1套自定义 + 跟随系统
// ============================================================

(function () {
  'use strict';

  // ==================== 主题定义 ====================

  const THEME_DEFINITIONS = {
    'follow-system': {
      id: 'follow-system',
      name: '跟随系统',
      icon: '🌓',
      primary: '#0077BE',
      bg: '#ffffff',
      text: '#333333',
      cssClass: 'theme-follow-system',
      isSystem: true
    },
    'deep-blue': {
      id: 'deep-blue',
      name: '深海蓝',
      icon: '🌊',
      primary: '#0077BE',
      bg: '#ffffff',
      text: '#333333',
      cssClass: 'theme-deep-blue',
      isDefault: true
    },
    'minimal-white': {
      id: 'minimal-white',
      name: '极简白',
      icon: '☁️',
      primary: '#666666',
      bg: '#fafafa',
      text: '#1a1a1a',
      cssClass: 'theme-minimal-white'
    },
    'classic-black': {
      id: 'classic-black',
      name: '经典黑',
      icon: '🌙',
      primary: '#bbbbbb',
      bg: '#1e1e1e',
      text: '#e0e0e0',
      cssClass: 'theme-classic-black'
    },
    'eye-green': {
      id: 'eye-green',
      name: '护眼绿',
      icon: '🍃',
      primary: '#52c41a',
      bg: '#f6ffed',
      text: '#333333',
      cssClass: 'theme-eye-green'
    },
    'warm-orange': {
      id: 'warm-orange',
      name: '暖阳橙',
      icon: '☀️',
      primary: '#fa8c16',
      bg: '#fff7e6',
      text: '#333333',
      cssClass: 'theme-warm-orange'
    },
    'night-purple': {
      id: 'night-purple',
      name: '暗夜紫',
      icon: '🌌',
      primary: '#722ed1',
      bg: '#1a1a2e',
      text: '#e0d7f5',
      cssClass: 'theme-night-purple'
    },
    'custom': {
      id: 'custom',
      name: '创建我的主题',
      icon: '➕',
      primary: '#0077BE',
      bg: '#ffffff',
      text: '#333333',
      cssClass: 'theme-custom',
      isCustom: true
    }
  };

  const PRESET_THEME_IDS = ['deep-blue', 'minimal-white', 'classic-black', 'eye-green', 'warm-orange', 'night-purple'];

  // CSS 类名映射
  const ALL_THEME_CLASSES = [
    'theme-deep-blue', 'theme-minimal-white', 'theme-classic-black',
    'theme-eye-green', 'theme-warm-orange', 'theme-night-purple',
    'theme-custom', 'theme-follow-system'
  ];

  // ==================== 主题自定义变量公式 ====================
  // 根据 primary / bg / text 三色，计算出一整套 CSS 变量
  // 这些变量会被注入到 body.theme-custom 或直接在 :root 上设置

  function hexToRgb(hex) {
    const h = hex.replace('#', '');
    if (h.length === 3) {
      return [
        parseInt(h[0] + h[0], 16),
        parseInt(h[1] + h[1], 16),
        parseInt(h[2] + h[2], 16)
      ];
    }
    return [
      parseInt(h.substring(0, 2), 16),
      parseInt(h.substring(2, 4), 16),
      parseInt(h.substring(4, 6), 16)
    ];
  }

  function rgbaFromHex(hex, alpha) {
    const [r, g, b] = hexToRgb(hex);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }

  function adjustColor(hex, amount) {
    let [r, g, b] = hexToRgb(hex);
    r = Math.max(0, Math.min(255, r + amount));
    g = Math.max(0, Math.min(255, g + amount));
    b = Math.max(0, Math.min(255, b + amount));
    return '#' + [r, g, b].map(c => c.toString(16).padStart(2, '0')).join('');
  }

  function isLightColor(hex) {
    const [r, g, b] = hexToRgb(hex);
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.5;
  }

  function computeThemeCSSVars(primary, bg, text) {
    const bgIsLight = isLightColor(bg);
    const primaryRgb = hexToRgb(primary).join(', ');
    const textRgb = hexToRgb(text).join(', ');

    // 根据背景明暗推算派生色
    const bgSecondary = bgIsLight ? adjustColor(bg, -8) : adjustColor(bg, 12);
    const bgTertiary = bgIsLight ? adjustColor(bg, -16) : adjustColor(bg, 20);
    const borderColor = bgIsLight ? adjustColor(bg, -30) : adjustColor(bg, 35);
    const borderLight = bgIsLight ? adjustColor(bg, -15) : adjustColor(bg, 22);
    const textSecondary = bgIsLight ? adjustColor(text, 80) : adjustColor(text, -50);
    const textMuted = bgIsLight ? adjustColor(text, 140) : adjustColor(text, -90);
    const accentHover = adjustColor(primary, bgIsLight ? -15 : 15);
    const inputBg = bgIsLight ? adjustColor(bg, -12) : adjustColor(bg, 16);
    const inputBorder = bgIsLight ? adjustColor(bg, -35) : adjustColor(bg, 40);
    const toggleBg = bgIsLight ? adjustColor(bg, -40) : adjustColor(bg, 45);
    const scrollbarThumb = bgIsLight ? adjustColor(bg, -60) : adjustColor(bg, 60);
    const kbdBg = bgIsLight ? adjustColor(bg, -12) : adjustColor(bg, 16);
    const kbdBorder = bgIsLight ? adjustColor(bg, -35) : adjustColor(bg, 40);
    const shadowBase = bgIsLight
      ? `rgba(0, 0, 0, ${bgIsLight ? '0.08' : '0.3'})`
      : 'rgba(0, 0, 0, 0.3)';
    const tabHover = bgIsLight ? adjustColor(bg, -18) : adjustColor(bg, 22);
    const itemHover = bgIsLight ? adjustColor(bg, -6) : adjustColor(bg, 10);
    const headerBg = bg;
    const tabActiveBg = bg;
    const tabInactive = bgIsLight ? adjustColor(text, 100) : adjustColor(text, -60);
    const overlayBg = bgIsLight ? 'rgba(0, 0, 0, 0.4)' : 'rgba(0, 0, 0, 0.6)';

    return {
      '--theme-primary': primary,
      '--theme-primary-rgb': primaryRgb,
      '--theme-bg': bg,
      '--theme-bg-rgb': hexToRgb(bg).join(', '),
      '--theme-text': text,
      '--theme-text-rgb': textRgb,
      '--panel-bg': bg,
      '--panel-bg-secondary': bgSecondary,
      '--panel-bg-tertiary': bgTertiary,
      '--panel-border': borderColor,
      '--panel-border-light': borderLight,
      '--panel-text-primary': text,
      '--panel-text-secondary': textSecondary,
      '--panel-text-muted': textMuted,
      '--panel-accent': primary,
      '--panel-accent-hover': accentHover,
      '--panel-accent-light': rgbaFromHex(primary, 0.08),
      '--panel-accent-border': rgbaFromHex(primary, 0.3),
      '--panel-danger': '#ea4335',
      '--panel-danger-hover': '#d33426',
      '--panel-success': '#0f9d58',
      '--panel-warning': '#f9ab00',
      '--panel-shadow-sm': `0 1px 3px ${shadowBase}`,
      '--panel-shadow': `0 4px 24px ${shadowBase}`,
      '--panel-shadow-lg': `0 12px 48px ${shadowBase}`,
      '--panel-radius-sm': '6px',
      '--panel-radius': '10px',
      '--panel-radius-lg': '14px',
      '--panel-radius-xl': '20px',
      '--panel-header-bg': headerBg,
      '--panel-tab-active-bg': tabActiveBg,
      '--panel-tab-hover-bg': tabHover,
      '--panel-tab-inactive': tabInactive,
      '--panel-item-hover': itemHover,
      '--panel-item-active': rgbaFromHex(primary, 0.08),
      '--panel-input-bg': inputBg,
      '--panel-input-border': inputBorder,
      '--panel-input-focus-border': primary,
      '--panel-input-focus-shadow': `0 0 0 3px ${rgbaFromHex(primary, 0.15)}`,
      '--panel-scrollbar-thumb': scrollbarThumb,
      '--panel-scrollbar-track': 'transparent',
      '--panel-highlight-bg': '#fff9c4',
      '--panel-highlight-color': text,
      '--panel-badge-bg': primary,
      '--panel-badge-color': '#ffffff',
      '--panel-toggle-bg': toggleBg,
      '--panel-toggle-active': primary,
      '--panel-kbd-bg': kbdBg,
      '--panel-kbd-border': kbdBorder,
      '--panel-overlay-bg': overlayBg
    };
  }

  // ==================== 状态管理 ====================

  // content-ready 握手标记
  let contentReady = false;
  let contentReadyFallbackTimer = null;

  const state = {
    currentTab: 'history-search',
    theme: 'deep-blue',           // 当前主题 ID
    customThemeColors: null,      // { primary, bg, text } 或 null
    fontSize: 'medium',
    enableFloatButton: true,
    settings: {},
    historySortOrder: 'desc',     // 'desc' = 时间倒序(新→旧), 'asc' = 时间正序(旧→新)
    currentSortOrder: 'desc',     // 当前对话搜索排序
    currentSearchResults: [],     // 缓存当前搜索结果
    currentSearchQuery: ''        // 缓存当前搜索关键词
  };

  // ==================== DOM 引用缓存 ====================

  let dom = {};

  function cacheDOMElements() {
    dom.body = document.body;
    dom.panelContainer = document.getElementById('ds-assistant-panel');
    dom.btnMinimize = document.getElementById('btn-minimize');
    dom.btnClose = document.getElementById('btn-close');
    dom.tabBtns = document.querySelectorAll('.tab-btn');
    dom.tabContents = document.querySelectorAll('.tab-content');
    dom.toastContainer = document.getElementById('toast-container');

    // 历史搜索
    dom.historySearchInput = document.getElementById('history-search-input');
    dom.btnClearHistory = document.getElementById('btn-clear-history');
    dom.historyCount = document.getElementById('history-count');
    dom.historyList = document.getElementById('history-list');
    dom.btnHistorySort = document.getElementById('btn-history-sort');
    dom.btnHistorySortLabel = document.getElementById('btn-history-sort-label');

    // 当前对话搜索
    dom.currentSearchInput = document.getElementById('current-search-input');
    dom.btnCurrentSearchExec = document.getElementById('btn-current-search-exec');
    dom.btnCurrentSort = document.getElementById('btn-current-sort');
    dom.btnCurrentSortLabel = document.getElementById('btn-current-sort-label');
    dom.currentSearchCount = document.getElementById('current-search-count');
    dom.currentSearchResults = document.getElementById('current-search-results');

    // 收藏夹
    dom.bookmarkSearchInput = document.getElementById('bookmark-search-input');
    dom.bookmarkSort = document.getElementById('bookmark-sort');
    dom.btnExportBookmarks = document.getElementById('btn-export-bookmarks');
    dom.btnImportBookmarks = document.getElementById('btn-import-bookmarks');
    dom.importFileInput = document.getElementById('import-file-input');
    dom.bookmarkCount = document.getElementById('bookmark-count');
    dom.bookmarkList = document.getElementById('bookmark-list');
    dom.messageBookmarkList = document.getElementById('message-bookmark-list');

    // 主题
    dom.themeCardGrid = document.getElementById('theme-card-grid');
    dom.toggleFloatBtn = document.getElementById('toggle-float-btn');
    dom.btnResetSettings = document.getElementById('btn-reset-settings');

    // 颜色取色器
    dom.colorPickerModal = document.getElementById('color-picker-modal');
    dom.customColorPrimary = document.getElementById('custom-color-primary');
    dom.customColorBg = document.getElementById('custom-color-bg');
    dom.customColorText = document.getElementById('custom-color-text');
    dom.customColorPrimaryVal = document.getElementById('custom-color-primary-val');
    dom.customColorBgVal = document.getElementById('custom-color-bg-val');
    dom.customColorTextVal = document.getElementById('custom-color-text-val');
    dom.colorPreviewArea = document.getElementById('color-preview-area');
    dom.btnColorPickerCancel = document.getElementById('btn-color-picker-cancel');
    dom.btnColorPickerSave = document.getElementById('btn-color-picker-save');

    // 关于 - 使用独立 HTML 文件加载
  }

  // ==================== 安全通信辅助函数 ====================

  function safeSendMessage(message, callback) {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      try {
        if (callback) {
          const p = chrome.runtime.sendMessage(message, callback);
          if (p && typeof p.catch === 'function') {
            p.catch(() => {
              console.warn('[DeepSeek助手] 插件上下文已失效（Extension context invalidated），请刷新页面');
              callback(null);
            });
          }
        } else {
          return chrome.runtime.sendMessage(message).catch(() => {
            console.warn('[DeepSeek助手] 插件上下文已失效（Extension context invalidated），请刷新页面');
            return null;
          });
        }
      } catch (e) {
        if (callback) {
          callback(null);
        }
        return Promise.reject(e);
      }
    } else {
      if (callback) {
        callback(null);
      }
      return Promise.resolve(null);
    }
  }

  // ==================== Storage 操作 ====================

  function storageSet(key, value) {
    return new Promise((resolve) => {
      safeSendMessage({ action: 'storage-set', key, value }, (res) => {
        resolve(res && res.success);
      });
    });
  }

  function storageGet(key) {
    return new Promise((resolve) => {
      safeSendMessage({ action: 'storage-get', key }, (res) => {
        resolve(res && res.data !== undefined ? res.data : null);
      });
    });
  }

  function storageRemove(key) {
    return new Promise((resolve) => {
      safeSendMessage({ action: 'storage-remove', key }, (res) => {
        resolve(res && res.success);
      });
    });
  }

  // ==================== 初始化 ====================

  async function init() {
    cacheDOMElements();

    // 加载设置
    const settings = await storageGet('settings');
    if (settings) {
      state.theme = settings.theme || 'deep-blue';
      state.customThemeColors = settings.customThemeColors || null;
      state.fontSize = settings.fontSize || 'medium';
      state.enableFloatButton = settings.enableFloatButton !== false;
      state.settings = settings;
    } else {
      // 默认设置
      state.theme = 'deep-blue';
      state.customThemeColors = null;
      state.fontSize = 'medium';
      state.enableFloatButton = true;
      state.settings = {
        theme: 'deep-blue',
        customThemeColors: null,
        fontSize: 'medium',
        enableFloatButton: true,
        maxHistoryItems: 50
      };
      await storageSet('settings', state.settings);
    }

    // 如果自定义主题有保存值，更新 THEME_DEFINITIONS
    if (state.customThemeColors) {
      THEME_DEFINITIONS['custom'].primary = state.customThemeColors.primary;
      THEME_DEFINITIONS['custom'].bg = state.customThemeColors.bg;
      THEME_DEFINITIONS['custom'].text = state.customThemeColors.text;
      THEME_DEFINITIONS['custom'].name = '我的主题';
    }

    // 应用主题
    applyTheme(state.theme);

    // 应用字体大小
    applyFontSize(state.fontSize);

    // 渲染主题卡片
    renderThemeCards();

    // 初始化浮动按钮开关状态
    if (dom.toggleFloatBtn) {
      dom.toggleFloatBtn.checked = state.enableFloatButton;
    }

    // 设置事件监听
    setupEventListeners();

    // 加载各标签页数据
    // 历史搜索：等待 content-ready 信号而不是立即请求
    if (contentReady) {
      loadHistoryData();
    } else {
      // 显示加载占位
      if (dom.historyList) {
        dom.historyList.innerHTML = '<div class="empty-state"><span class="empty-icon">&#x1F4AD;</span><p>正在连接...</p><p class="empty-hint">等待页面就绪...</p></div>';
      }
      if (dom.historyCount) {
        dom.historyCount.textContent = '正在连接页面...';
      }
      startContentReadyFallback();
    }
    loadBookmarkData();

    // 监听 chrome.storage 变更（messageBookmarks 写入时自动刷新消息卡片列表）
    // ★ 不依赖 chrome.runtime.sendMessage 跨上下文传递，比消息监听更可靠
    chrome.storage.onChanged.addListener(function(changes, areaName) {
      if (areaName === 'local' && changes.messageBookmarks) {
        if (dom.messageBookmarkList) {
          renderMessageBookmarks();
        }
      }
    });
  }

  // ==================== 面板拖动 ====================

  // ==================== 面板拖动 ====================

  function onDragMove(left, top) {
    // content.js 负责 iframe 的定位（style.left/top on iframe）
    // 这里同步设置容器内定位，确保样式一致性
    const panel = document.getElementById('ds-assistant-panel');
    if (!panel) return;
    panel.style.position = 'fixed';
    panel.style.left = '0';
    panel.style.top = '0';
  }

  function onDragEnd(left, top) {
    onDragMove(left, top);
  }

  function resetDragTransform() {
    const panel = document.getElementById('ds-assistant-panel');
    if (!panel) return;
    panel.style.position = '';
    panel.style.left = '';
    panel.style.top = '';
  }

  // ==================== 主题系统 ====================

  function applyTheme(themeId) {
    // 移除所有主题类
    ALL_THEME_CLASSES.forEach(cls => dom.body.classList.remove(cls));

    if (themeId === 'follow-system') {
      // 跟随系统：检测 prefers-color-scheme
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      const effectiveTheme = prefersDark ? 'classic-black' : 'minimal-white';
      dom.body.classList.add(THEME_DEFINITIONS[effectiveTheme].cssClass);
    } else if (themeId === 'custom') {
      // 自定义主题：动态注入 CSS 变量
      dom.body.classList.add('theme-custom');
      applyCustomThemeVars();
    } else {
      // 预设主题
      const def = THEME_DEFINITIONS[themeId];
      if (def && def.cssClass) {
        dom.body.classList.add(def.cssClass);
      }
    }

    // 更新主题卡片高亮
    updateThemeCardHighlight(themeId);

    // 同步到 content.js（悬浮按钮主题）
    syncThemeToContent(themeId);

    // 保存到 storage
    state.theme = themeId;
    saveSettings();
  }

  function applyCustomThemeVars() {
    const colors = state.customThemeColors || {
      primary: '#1890ff',
      bg: '#ffffff',
      text: '#333333'
    };
    const vars = computeThemeCSSVars(colors.primary, colors.bg, colors.text);

    Object.entries(vars).forEach(([key, value]) => {
      dom.body.style.setProperty(key, value);
    });
  }

  function syncThemeToContent(themeId) {
    // 获取当前主题的颜色信息
    let themeInfo;
    if (themeId === 'follow-system') {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      themeInfo = THEME_DEFINITIONS[prefersDark ? 'classic-black' : 'minimal-white'];
    } else {
      themeInfo = THEME_DEFINITIONS[themeId];
    }

    if (!themeInfo) return;

    // 发送主题信息到 content.js
    safeSendMessage({
      action: 'settings-changed',
      settings: {
        theme: themeId,
        themeColors: {
          primary: themeInfo.primary,
          bg: themeInfo.bg,
          text: themeInfo.text
        },
        enableFloatButton: state.enableFloatButton
      }
    });

    // 同时通过 postMessage 发送（面板在 iframe 内）
    try {
      window.parent.postMessage({
        action: 'theme-changed',
        theme: themeId,
        themeColors: {
          primary: themeInfo.primary,
          bg: themeInfo.bg,
          text: themeInfo.text
        }
      }, '*');
    } catch (e) {}
  }

  function getEffectiveTheme(themeId) {
    if (themeId === 'follow-system') {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      return THEME_DEFINITIONS[prefersDark ? 'classic-black' : 'minimal-white'];
    }
    return THEME_DEFINITIONS[themeId];
  }

  function applyFontSize(size) {
    dom.body.classList.remove('font-small', 'font-medium', 'font-large');
    dom.body.classList.add('font-' + size);
    state.fontSize = size;
    saveSettings();
  }

  function saveSettings() {
    state.settings = {
      theme: state.theme,
      customThemeColors: state.customThemeColors,
      fontSize: state.fontSize,
      enableFloatButton: state.enableFloatButton,
      maxHistoryItems: state.settings.maxHistoryItems || 50
    };
    storageSet('settings', state.settings);
  }

  // ==================== 主题卡片渲染 ====================

  function renderThemeCards() {
    if (!dom.themeCardGrid) return;
    dom.themeCardGrid.innerHTML = '';

    // 卡片顺序：跟随系统 + 6 预设 + 自定义
    const cardOrder = ['follow-system', ...PRESET_THEME_IDS, 'custom'];

    cardOrder.forEach(themeId => {
      const def = THEME_DEFINITIONS[themeId];
      const card = document.createElement('div');
      card.className = 'theme-card';
      card.setAttribute('data-theme', themeId);

      // 自定义主题特殊样式
      if (def.isCustom) {
        card.classList.add('theme-card-custom');
      } else if (def.isSystem) {
        card.classList.add('theme-card-system');
      }

      // 是否当前激活
      if (state.theme === themeId) {
        card.classList.add('active');
      }

      // 图标
      if (def.icon) {
        const iconEl = document.createElement('span');
        iconEl.className = 'theme-card-icon';
        iconEl.textContent = def.icon;
        card.appendChild(iconEl);
      }

      // 名称
      const nameEl = document.createElement('span');
      nameEl.className = 'theme-card-name';
      let displayName = def.name;
      if (def.isCustom && state.customThemeColors) {
        displayName = '我的主题';
      } else if (def.isCustom && !state.customThemeColors) {
        displayName = '➕ 创建我的主题';
      }
      nameEl.textContent = displayName;
      card.appendChild(nameEl);

      // 色块预览
      if (!def.isSystem) {
        const previewEl = document.createElement('div');
        previewEl.className = 'theme-card-preview';
        const previewPrimary = document.createElement('span');
        previewPrimary.className = 'preview-primary';
        previewPrimary.style.setProperty('--card-preview-primary', def.primary);
        previewPrimary.style.backgroundColor = def.primary;
        const previewBg = document.createElement('span');
        previewBg.className = 'preview-bg';
        previewBg.style.setProperty('--card-preview-bg', def.bg);
        previewBg.style.backgroundColor = def.bg;
        previewEl.appendChild(previewPrimary);
        previewEl.appendChild(previewBg);
        card.appendChild(previewEl);
      } else {
        // 跟随系统：显示双色预览
        const previewEl = document.createElement('div');
        previewEl.className = 'theme-card-preview';
        const previewLight = document.createElement('span');
        previewLight.className = 'preview-primary';
        previewLight.style.backgroundColor = '#fafafa';
        const previewDark = document.createElement('span');
        previewDark.className = 'preview-bg';
        previewDark.style.backgroundColor = '#1e1e1e';
        previewDark.style.flex = '1';
        previewEl.appendChild(previewLight);
        previewEl.appendChild(previewDark);
        card.appendChild(previewEl);
      }

      // 激活标记
      const badgeEl = document.createElement('span');
      badgeEl.className = 'card-active-badge';
      badgeEl.textContent = '使用中';
      card.appendChild(badgeEl);

      // 点击事件
      card.addEventListener('click', () => {
        if (def.isCustom) {
          // 打开取色器
          openColorPicker();
        } else {
          // 预设主题 / 跟随系统
          applyTheme(themeId);
          renderThemeCards();
        }
      });

      dom.themeCardGrid.appendChild(card);
    });
  }

  function updateThemeCardHighlight(activeThemeId) {
    if (!dom.themeCardGrid) return;
    const cards = dom.themeCardGrid.querySelectorAll('.theme-card');
    cards.forEach(card => {
      const themeId = card.getAttribute('data-theme');
      if (themeId === activeThemeId) {
        card.classList.add('active');
      } else {
        card.classList.remove('active');
      }
    });
  }

  // ==================== 自定义颜色取色器 ====================

  function openColorPicker() {
    if (!dom.colorPickerModal) return;

    // 加载当前自定义色值或默认值
    const colors = state.customThemeColors || {
      primary: '#1890ff',
      bg: '#ffffff',
      text: '#333333'
    };

    dom.customColorPrimary.value = colors.primary;
    dom.customColorBg.value = colors.bg;
    dom.customColorText.value = colors.text;
    dom.customColorPrimaryVal.textContent = colors.primary;
    dom.customColorBgVal.textContent = colors.bg;
    dom.customColorTextVal.textContent = colors.text;

    // 更新预览
    updateColorPreview(colors.primary, colors.bg, colors.text);

    // 显示模态框
    dom.colorPickerModal.style.display = 'flex';
  }

  function closeColorPicker() {
    if (dom.colorPickerModal) {
      dom.colorPickerModal.style.display = 'none';
    }
  }

  function updateColorPreview(primary, bg, text) {
    if (dom.colorPreviewArea) {
      dom.colorPreviewArea.style.backgroundColor = bg;
      dom.colorPreviewArea.style.color = text;
      dom.colorPreviewArea.style.borderColor = primary;
    }
  }

  function saveCustomTheme() {
    const primary = dom.customColorPrimary.value;
    const bg = dom.customColorBg.value;
    const text = dom.customColorText.value;

    // 保存自定义色值
    state.customThemeColors = { primary, bg, text };

    // 更新 THEME_DEFINITIONS
    THEME_DEFINITIONS['custom'].primary = primary;
    THEME_DEFINITIONS['custom'].bg = bg;
    THEME_DEFINITIONS['custom'].text = text;
    THEME_DEFINITIONS['custom'].name = '我的主题';

    // 保存到 storage
    saveSettings();

    // 应用自定义主题
    applyTheme('custom');

    // 重新渲染卡片
    renderThemeCards();

    // 关闭取色器
    closeColorPicker();

    showToast('✅ 自定义主题已保存并应用');
  }

  // ==================== 跟随系统：监听系统主题变化 ====================

  function setupSystemThemeListener() {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

    const handleChange = (e) => {
      if (state.theme === 'follow-system') {
        // 重新应用跟随系统主题
        applyTheme('follow-system');
      }
    };

    // 使用现代 API
    if (mediaQuery.addEventListener) {
      mediaQuery.addEventListener('change', handleChange);
    } else {
      // 兼容旧版
      mediaQuery.addListener(handleChange);
    }
  }

  // ==================== 事件监听 ====================

  function setupEventListeners() {
    // 标签页切换
    dom.tabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const tabId = btn.getAttribute('data-tab');
        switchTab(tabId);
      });
    });

    // 最小化
    if (dom.btnMinimize) {
      dom.btnMinimize.addEventListener('click', () => {
        resetDragTransform();
        try {
          window.parent.postMessage({ action: 'minimize-panel' }, '*');
        } catch (e) {}
      });
    }

    // 关闭
    if (dom.btnClose) {
      dom.btnClose.addEventListener('click', () => {
        resetDragTransform();
        try {
          window.parent.postMessage({ action: 'close-panel' }, '*');
        } catch (e) {}
        safeSendMessage({ action: 'close-panel' });
      });
    }

    // 浮动按钮开关
    if (dom.toggleFloatBtn) {
      dom.toggleFloatBtn.addEventListener('change', () => {
        state.enableFloatButton = dom.toggleFloatBtn.checked;
        saveSettings();
        safeSendMessage({
          action: 'toggle-float-btn',
          enabled: state.enableFloatButton
        });
      });
    }

    // 恢复默认设置
    if (dom.btnResetSettings) {
      dom.btnResetSettings.addEventListener('click', resetSettings);
    }

    // 字体大小
    const fontOptions = document.querySelectorAll('.font-option');
    fontOptions.forEach(opt => {
      opt.addEventListener('click', () => {
        const font = opt.getAttribute('data-font');
        if (font) applyFontSize(font);

        // 更新 radio 状态
        fontOptions.forEach(o => {
          const radio = o.querySelector('input[type="radio"]');
          if (radio) radio.checked = false;
        });
        const radio = opt.querySelector('input[type="radio"]');
        if (radio) radio.checked = true;
      });
    });

    // 历史搜索
    if (dom.historySearchInput) {
      dom.historySearchInput.addEventListener('input', debounce(loadHistoryData, 300));
      dom.historySearchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          dom.historySearchInput.value = '';
          loadHistoryData();
        }
      });
    }
    if (dom.btnClearHistory) {
      dom.btnClearHistory.addEventListener('click', clearAllHistory);
    }
    if (dom.btnHistorySort) {
      dom.btnHistorySort.addEventListener('click', toggleHistorySort);
    }

    // 当前对话搜索
    if (dom.currentSearchInput) {
      dom.currentSearchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') executeCurrentSearch();
        if (e.key === 'Escape') {
          dom.currentSearchInput.value = '';
          dom.currentSearchCount.textContent = '输入关键词后按回车或点击搜索';
          dom.currentSearchResults.innerHTML = getSearchEmptyHTML();
        }
      });
    }
    if (dom.btnCurrentSearchExec) {
      dom.btnCurrentSearchExec.addEventListener('click', executeCurrentSearch);
    }
    if (dom.btnCurrentSort) {
      dom.btnCurrentSort.addEventListener('click', toggleCurrentSort);
    }

    // 收藏夹
    if (dom.bookmarkSearchInput) {
      dom.bookmarkSearchInput.addEventListener('input', debounce(loadBookmarkData, 300));
    }
    if (dom.bookmarkSort) {
      dom.bookmarkSort.addEventListener('change', loadBookmarkData);
    }
    if (dom.btnExportBookmarks) {
      dom.btnExportBookmarks.addEventListener('click', exportBookmarks);
    }
    if (dom.btnImportBookmarks) {
      dom.btnImportBookmarks.addEventListener('click', () => {
        if (dom.importFileInput) dom.importFileInput.click();
      });
    }
    if (dom.importFileInput) {
      dom.importFileInput.addEventListener('change', importBookmarks);
    }

    // 颜色取色器
    if (dom.customColorPrimary) {
      dom.customColorPrimary.addEventListener('input', () => {
        const val = dom.customColorPrimary.value;
        dom.customColorPrimaryVal.textContent = val;
        updateColorPreview(val, dom.customColorBg.value, dom.customColorText.value);
      });
    }
    if (dom.customColorBg) {
      dom.customColorBg.addEventListener('input', () => {
        const val = dom.customColorBg.value;
        dom.customColorBgVal.textContent = val;
        updateColorPreview(dom.customColorPrimary.value, val, dom.customColorText.value);
      });
    }
    if (dom.customColorText) {
      dom.customColorText.addEventListener('input', () => {
        const val = dom.customColorText.value;
        dom.customColorTextVal.textContent = val;
        updateColorPreview(dom.customColorPrimary.value, dom.customColorBg.value, val);
      });
    }
    if (dom.btnColorPickerCancel) {
      dom.btnColorPickerCancel.addEventListener('click', closeColorPicker);
    }
    if (dom.btnColorPickerSave) {
      dom.btnColorPickerSave.addEventListener('click', saveCustomTheme);
    }
    // 点击取色器遮罩关闭
    if (dom.colorPickerModal) {
      dom.colorPickerModal.addEventListener('click', (e) => {
        if (e.target === dom.colorPickerModal) {
          closeColorPicker();
        }
      });
    }

    // 键盘快捷键
    document.addEventListener('keydown', (e) => {
      // Esc 关闭取色器
      if (e.key === 'Escape' && dom.colorPickerModal && dom.colorPickerModal.style.display === 'flex') {
        closeColorPicker();
        e.preventDefault();
      }
      // Alt+K / Esc 关闭面板
      if (e.key === 'Escape') {
        try {
          window.parent.postMessage({ action: 'close-panel' }, '*');
        } catch (e2) {}
          safeSendMessage({ action: 'close-panel' });
      }
    });

    // 监听来自 content.js 的消息（通过 postMessage）
    window.addEventListener('message', (event) => {
      if (!event.data || !event.data.action) return;
      const { action } = event.data;

      switch (action) {
        case 'content-ready':
          // ★ 双向就绪握手：收到 content.js 的就绪信号
          contentReady = true;
          if (contentReadyFallbackTimer) {
            clearTimeout(contentReadyFallbackTimer);
            contentReadyFallbackTimer = null;
          }
          // 如果当前正在历史搜索标签页，立即加载
          if (state.currentTab === 'history-search') {
            loadHistoryData();
          }
          break;
        case 'new-bookmark':
          loadBookmarkData();
          break;
        case 'drag-move':
          onDragMove(event.data.left, event.data.top);
          break;
        case 'drag-end':
          onDragEnd(event.data.left, event.data.top);
          break;
        default:
          break;
      }
    });

    // 面板标题栏 mousedown → 开始拖动
    const panelHeader = document.querySelector('.panel-header');
    if (panelHeader) {
      panelHeader.addEventListener('mousedown', (e) => {
        // 排除按钮点击（最小化/关闭按钮不触发拖动）
        if (e.target.closest('button')) return;
        e.preventDefault();
        try {
          window.parent.postMessage({
            action: 'drag-start',
            offsetX: e.clientX,
            offsetY: e.clientY
          }, '*');
        } catch (err) {}
      });
    }

    // 设置跟随系统主题监听
    setupSystemThemeListener();
  }

  // ==================== 标签页切换 ====================

  function switchTab(tabId) {
    state.currentTab = tabId;

    // 更新标签按钮
    dom.tabBtns.forEach(btn => {
      const btnTab = btn.getAttribute('data-tab');
      if (btnTab === tabId) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    // "关于"标签：用 JS 注入干净的内联 HTML
    if (tabId === 'about') {
      const aboutTab = document.getElementById('tab-about');
      if (aboutTab) {
        aboutTab.innerHTML = `<div style="padding:16px; box-sizing:border-box; height:100%; overflow-y:auto; color:inherit;">
<h2 style="margin:0 0 4px 0;">DeepSeek 助手</h2>
<p style="opacity:0.7; margin:0 0 16px 0; font-size:13px;">版本 1.0.0</p>
<h3 style="margin:0 0 8px 0;">功能介绍</h3>
<ul style="margin:0; padding-left:20px;">
<li style="margin-bottom:6px;">🔍 <strong>历史搜索</strong> — 检索左侧对话列表，支持时间排序与关键词筛选</li>
<li style="margin-bottom:6px;">📄 <strong>当前对话搜索</strong> — 搜索页面内已加载消息，点击后滚动定位并红框高亮闪烁</li>
<li style="margin-bottom:6px;">⭐ <strong>收藏夹</strong> — 悬浮按钮 / 快捷键 / 右键菜单三种方式收藏，支持排序、搜索与 JSON/TXT 导出备份</li>
<li style="margin-bottom:6px;">🎨 <strong>主题切换</strong> — 6 套预设主题 + 自定义取色器 + 跟随系统，面板与悬浮按钮同步换肤</li>
<li style="margin-bottom:6px;">🖱️ <strong>面板拖拽</strong> — 面板可通过标题栏自由拖拽移动位置</li>
</ul>
<h3 style="margin:20px 0 8px 0;">快捷键</h3>
<table style="width:100%; border-collapse:collapse; margin:0; text-align:left;">
<tr><td style="padding:6px 0; white-space:nowrap; border-bottom:1px solid rgba(128,128,128,0.15);"><kbd style="background:rgba(128,128,128,0.1); border:1px solid rgba(128,128,128,0.2); border-radius:4px; padding:2px 6px; font-size:12px;">Alt</kbd> + <kbd style="background:rgba(128,128,128,0.1); border:1px solid rgba(128,128,128,0.2); border-radius:4px; padding:2px 6px; font-size:12px;">K</kbd></td><td style="padding:6px 0; border-bottom:1px solid rgba(128,128,128,0.15);">呼出 / 关闭面板</td></tr>
<tr><td style="padding:6px 0; white-space:nowrap; border-bottom:1px solid rgba(128,128,128,0.15);"><kbd style="background:rgba(128,128,128,0.1); border:1px solid rgba(128,128,128,0.2); border-radius:4px; padding:2px 6px; font-size:12px;">Ctrl</kbd> + <kbd style="background:rgba(128,128,128,0.1); border:1px solid rgba(128,128,128,0.2); border-radius:4px; padding:2px 6px; font-size:12px;">Shift</kbd> + <kbd style="background:rgba(128,128,128,0.1); border:1px solid rgba(128,128,128,0.2); border-radius:4px; padding:2px 6px; font-size:12px;">X</kbd></td><td style="padding:6px 0; border-bottom:1px solid rgba(128,128,128,0.15);">收藏当前对话</td></tr>
<tr><td style="padding:6px 0; white-space:nowrap; border-bottom:1px solid rgba(128,128,128,0.15);"><kbd style="background:rgba(128,128,128,0.1); border:1px solid rgba(128,128,128,0.2); border-radius:4px; padding:2px 6px; font-size:12px;">Esc</kbd></td><td style="padding:6px 0; border-bottom:1px solid rgba(128,128,128,0.15);">关闭面板</td></tr>
<tr><td style="padding:6px 0; white-space:nowrap; border-bottom:1px solid rgba(128,128,128,0.15);"><kbd style="background:rgba(128,128,128,0.1); border:1px solid rgba(128,128,128,0.2); border-radius:4px; padding:2px 6px; font-size:12px;">Enter</kbd></td><td style="padding:6px 0; border-bottom:1px solid rgba(128,128,128,0.15);">执行搜索</td></tr>
</table>
<div style="margin-top:24px; padding-top:12px; border-top:1px solid rgba(128,128,128,0.15); font-size:11px; opacity:0.6; text-align:center;">
<p style="margin:0 0 4px 0;">🔒 所有数据均安全存储于本地，绝不收集或上传任何个人信息。</p>
<p style="margin:0;">基于 Manifest V3 开发 · 兼容 Edge / Chrome</p>
</div>
</div>`;
      }
      // 清理可能残留的覆盖层
      const oldOverlay = document.getElementById('ds-about-overlay');
      if (oldOverlay) oldOverlay.remove();
      // 继续执行下面的标签页激活逻辑，不加 return
    }

    // 更新内容区
    dom.tabContents.forEach(content => {
      content.classList.remove('active');
    });

    const targetContent = document.getElementById('tab-' + tabId);
    if (targetContent) {
      targetContent.classList.add('active');
    }

    // 切换到主题标签时重新渲染（确保颜色预览最新）
    if (tabId === 'theme') {
      renderThemeCards();
    }

    // 切换到历史搜索标签时自动抓取对话列表
    if (tabId === 'history-search') {
      if (contentReady) {
        loadHistoryData();
      } else {
        // content 尚未就绪：显示加载提示，等待 content-ready 信号
        if (dom.historyList) {
          dom.historyList.innerHTML = '<div class="empty-state"><span class="empty-icon">&#x1F4AD;</span><p>正在连接...</p><p class="empty-hint">等待页面就绪...</p></div>';
        }
        if (dom.historyCount) {
          dom.historyCount.textContent = '正在连接页面...';
        }
        startContentReadyFallback();
      }
    }
  }

  // ==================== 历史搜索 ====================

  let _cachedConversations = []; // 缓存从侧边栏抓取的对话列表

  async function loadHistoryData() {
    if (!dom.historyList) return;

    const query = dom.historySearchInput ? dom.historySearchInput.value.trim().toLowerCase() : '';

    // 显示加载中状态
    dom.historyCount.textContent = '正在加载对话列表...';
    dom.historyList.innerHTML = '<div class="empty-state"><span class="empty-icon">&#x1F4AD;</span><p>正在加载...</p><p class="empty-hint">正在获取左侧对话列表</p></div>';

    // 通过 background 中转请求侧边栏对话列表，带自动重试
    let conversations = [];
    let fetchError = null;
    const MAX_RETRIES = 5;
    const RETRY_DELAY_MS = 500;

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      try {
        const response = await safeSendMessage({ action: 'fetch-sidebar-conversations' });
        if (response && response.success) {
          conversations = response.conversations || [];
          _cachedConversations = conversations;
          if (conversations.length > 0) break; // 有数据就跳出
          // 空结果：继续重试，可能 content.js 还没准备好
        }
      } catch (e) {
        fetchError = e;
        // 请求失败，继续重试
      }

      if (attempt < MAX_RETRIES) {
        dom.historyCount.textContent = `正在加载... (${attempt}/${MAX_RETRIES - 1})`;
        await new Promise(r => setTimeout(r, RETRY_DELAY_MS));
      }
    }

    // 重试用完仍无数据 → 回退到缓存
    if (conversations.length === 0 && _cachedConversations.length > 0) {
      conversations = _cachedConversations;
    }

    // 回退到存储的搜索历史
    if (conversations.length === 0) {
      const history = await storageGet('searchHistory');
      const items = history || [];
      conversations = items.map(item => ({
        title: item.query || item.title || '未知搜索',
        url: item.url || '',
        id: 'hist_' + Math.random().toString(36).slice(2),
        type: item.type || '搜索',
        timestamp: item.timestamp || null
      }));
    }

    // 按时间排序
    if (state.historySortOrder === 'desc') {
      conversations.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    } else {
      conversations.sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
    }

    let filtered = conversations;
    if (query) {
      filtered = conversations.filter(c =>
        (c.title && c.title.toLowerCase().includes(query))
      );
    }

    // 更新排序按钮标签
    updateHistorySortLabel();

    dom.historyCount.textContent = `共 ${filtered.length} 条记录`;

    if (filtered.length === 0) {
      dom.historyList.innerHTML = conversations.length === 0
        ? getHistoryEmptyHTML()
        : '<div class="empty-state"><span class="empty-icon">🔍</span><p>未找到匹配记录</p></div>';
      return;
    }

    dom.historyList.innerHTML = filtered.map((item, index) =>
      renderHistoryItem(item, index, query)
    ).join('');

    // 绑定点击事件
    bindHistoryItemEvents();
  }

  function renderHistoryItem(item, index, query) {
    const title = item.title || item.query || '未命名对话';
    const url = item.url || '';
    const timestamp = item.timestamp ? new Date(item.timestamp).toLocaleString('zh-CN') : '';
    const type = item.type || '对话';
    // 将标题中的匹配关键词用 <mark> 高亮
    const highlightedTitle = query ? highlightText(title, query) : escapeHTML(title);

    return `
      <div class="list-item" data-index="${index}" data-url="${escapeHTML(url)}">
        <div class="list-item-title">${highlightedTitle}</div>
        <div class="list-item-meta">
          <span class="list-item-tag">${escapeHTML(type)}</span>
          ${timestamp ? `<span>${escapeHTML(timestamp)}</span>` : ''}
          ${url ? `<span class="list-item-link" style="font-size:10px;color:var(--panel-text-muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:200px;">${escapeHTML(url)}</span>` : ''}
        </div>
      </div>
    `;
  }

  function bindHistoryItemEvents() {
    const listItems = dom.historyList.querySelectorAll('.list-item');
    listItems.forEach(el => {
      el.addEventListener('click', () => {
        const url = el.getAttribute('data-url');
        if (url) {
          safeSendMessage({ action: 'open-url', url });
        }
      });
      // 右键收藏 — 从列表项中提取标题和 URL
      el.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        const titleEl = el.querySelector('.list-item-title');
        const title = titleEl ? titleEl.textContent || '' : '';
        const url = el.getAttribute('data-url') || '';
        bookmarkViaContent(title, url, '');
      });
    });
  }

  async function clearAllHistory() {
    await storageSet('searchHistory', []);
    loadHistoryData();
    showToast('🗑️ 搜索历史已清空');
  }

  function getHistoryEmptyHTML() {
    return `
      <div class="empty-state">
        <span class="empty-icon">💭</span>
        <p>暂无搜索历史</p>
        <p class="empty-hint">使用快捷键 Alt+K 搜索内容后，记录将显示在此处</p>
      </div>
    `;
  }

  // ==================== 当前对话搜索 ====================

  async function executeCurrentSearch() {
    const query = dom.currentSearchInput ? dom.currentSearchInput.value.trim() : '';
    if (!query) {
      showToast('⚠️ 请输入搜索关键词');
      return;
    }

    dom.currentSearchCount.textContent = '正在搜索...';

    safeSendMessage({
      action: 'search-current-page',
      query
    }, (response) => {
      if (response && response.success) {
        // 按当前排序设置排序
        let results = response.results || [];
        if (state.currentSortOrder === 'desc') {
          results.sort((a, b) => (b.timestamp || b.index || 0) - (a.timestamp || a.index || 0));
        } else {
          results.sort((a, b) => (a.timestamp || a.index || 0) - (b.timestamp || b.index || 0));
        }
        renderSearchResults(results, query);
      } else {
        dom.currentSearchCount.textContent = '搜索失败，请重试';
        dom.currentSearchResults.innerHTML = getSearchEmptyHTML();
      }
    });
  }

  function renderSearchResults(results, query) {
    if (!dom.currentSearchResults) return;

    // 缓存搜索结果
    state.currentSearchResults = results || [];
    state.currentSearchQuery = query || '';

    // 显示排序按钮
    if (dom.btnCurrentSort) {
      dom.btnCurrentSort.style.display = '';
    }

    if (!results || results.length === 0) {
      dom.currentSearchCount.textContent = `未找到"${query}"的相关内容`;
      dom.currentSearchResults.innerHTML = `
        <div class="empty-state">
          <span class="empty-icon">🔎</span>
          <p>未找到匹配内容</p>
          <p class="empty-hint">请尝试其他关键词</p>
        </div>
      `;
      if (dom.btnCurrentSort) dom.btnCurrentSort.style.display = 'none';
      return;
    }

    dom.currentSearchCount.textContent = `找到 ${results.length} 条匹配结果`;

    dom.currentSearchResults.innerHTML = results.map((result, index) => {
      const snippet = result.snippet ? highlightText(result.snippet, query) : '';
      const title = result.title || `匹配项 #${index + 1}`;
      const type = result.type || '内容';

      const url = result.url || '';
      // 使用 result.index（filteredIdx）而非 map 循环 index，确保 scrollToResult 定位正确
      const targetIdx = result.index !== undefined ? result.index : index;

      // 标题也做关键词高亮
      const highlightedTitle = highlightText(title, query);

      return `
        <div class="list-item" data-index="${targetIdx}" data-url="${escapeHTML(url)}">
          <div class="list-item-title">${highlightedTitle}</div>
          <div class="list-item-snippet" style="font-size:12px;color:var(--panel-text-secondary);line-height:1.6;margin-bottom:6px;">${snippet}</div>
          <div class="list-item-meta">
            <span class="list-item-tag">${escapeHTML(type)}</span>
          </div>
        </div>
      `;
    }).join('');

    // 绑定点击滚动
    bindSearchResultEvents(results);
  }

  function bindSearchResultEvents(results) {
    const items = dom.currentSearchResults.querySelectorAll('.list-item');
    items.forEach(el => {
      el.addEventListener('click', () => {
        const url = el.getAttribute('data-url');
        if (url) {
          safeSendMessage({ action: 'open-url', url });
        } else {
          const index = parseInt(el.getAttribute('data-index'));
          safeSendMessage({ action: 'scroll-to-result', index });
        }
      });
      // 右键收藏 — 从列表项中提取标题和 URL
      el.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        const snippet = el.querySelector('.list-item-snippet')?.textContent || '';
        const titleEl = el.querySelector('.list-item-title');
        const title = titleEl ? titleEl.textContent || '' : '';
        const url = el.getAttribute('data-url') || '';
        bookmarkViaContent(title, url, snippet);
      });
    });
  }

  function getSearchEmptyHTML() {
    return `
      <div class="empty-state">
        <span class="empty-icon">🔎</span>
        <p>在当前页面对话内容中搜索</p>
        <p class="empty-hint">支持搜索对话标题、用户消息和AI回复内容</p>
      </div>
    `;
  }

  // ==================== 收藏夹 ====================

  async function loadBookmarkData() {
    if (!dom.bookmarkList) return;

    const bookmarks = await storageGet('bookmarks') || [];
    const query = dom.bookmarkSearchInput ? dom.bookmarkSearchInput.value.trim().toLowerCase() : '';
    const sort = dom.bookmarkSort ? dom.bookmarkSort.value : 'newest';

    let filtered = bookmarks;
    if (query) {
      filtered = bookmarks.filter(b =>
        (b.title && b.title.toLowerCase().includes(query)) ||
        (b.url && b.url.toLowerCase().includes(query)) ||
        (b.snippet && b.snippet.toLowerCase().includes(query)) ||
        (b.note && b.note.toLowerCase().includes(query))
      );
    }

    // 排序
    if (sort === 'newest') {
      filtered.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    } else if (sort === 'oldest') {
      filtered.sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
    } else if (sort === 'title') {
      filtered.sort((a, b) => (a.title || '').localeCompare(b.title || '', 'zh-CN'));
    }

    dom.bookmarkCount.textContent = `共 ${filtered.length} 项收藏`;

    if (filtered.length === 0) {
      dom.bookmarkList.innerHTML = bookmarks.length === 0
        ? getBookmarkEmptyHTML()
        : '<div class="empty-state"><span class="empty-icon">🔍</span><p>未找到匹配收藏项</p></div>';
    } else {
      dom.bookmarkList.innerHTML = filtered.map(b => renderBookmarkItem(b, query)).join('');
      bindBookmarkItemEvents(filtered);
    }

    // 同时渲染消息收藏（支持搜索过滤）
    renderMessageBookmarks(query);
  }

  function renderBookmarkItem(bookmark, query) {
    const title = bookmark.title || '未命名对话';
    const snippet = bookmark.snippet ? bookmark.snippet.slice(0, 100) : '';
    const timestamp = bookmark.timestamp ? new Date(bookmark.timestamp).toLocaleString('zh-CN') : '';
    const id = bookmark.id || '';
    // 关键词高亮
    const highlightedTitle = query ? highlightText(title, query) : escapeHTML(title);
    const highlightedSnippet = query && snippet ? highlightText(snippet, query) : escapeHTML(snippet || '');
    const highlightedNote = query && bookmark.note ? highlightText(bookmark.note, query) : (bookmark.note ? escapeHTML(bookmark.note) : '');

    return `
      <div class="list-item" data-id="${escapeHTML(id)}" data-url="${escapeHTML(bookmark.url || '')}">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:4px;">
          <div class="list-item-title" style="flex:1;margin-bottom:0;">${highlightedTitle}</div>
          ${timestamp ? `<span class="msg-card-time" style="flex-shrink:0;margin-left:8px;white-space:nowrap;">${escapeHTML(timestamp)}</span>` : ''}
        </div>
        ${snippet ? `<div style="font-size:12px;color:var(--panel-text-secondary);margin-bottom:4px;">${highlightedSnippet}</div>` : ''}
        ${bookmark.note ? `<div style="font-size:12px;color:var(--panel-accent);margin-bottom:4px;font-weight:500;">📝 ${highlightedNote}</div>` : ''}
        <div class="list-item-actions">
          <button class="btn btn-outline btn-sm bookmark-open-btn">打开</button>
          <button class="btn btn-danger-outline btn-sm bookmark-delete-btn">删除</button>
        </div>
      </div>
    `;
  }

  function bindBookmarkItemEvents(bookmarks) {
    const items = dom.bookmarkList.querySelectorAll('.list-item');
    items.forEach(el => {
      // 打开链接 — 分享链接用 window.open 在新标签页打开
      const openBtn = el.querySelector('.bookmark-open-btn');
      if (openBtn) {
        openBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          const url = el.getAttribute('data-url');
          if (url) {
            __openBookmarkUrl__(url);
          }
        });
      }

      // 标题点击也打开 — 分享链接用 window.open 在新标签页打开
      el.addEventListener('click', (e) => {
        if (e.target.classList.contains('bookmark-delete-btn') ||
            e.target.classList.contains('bookmark-open-btn')) {
          return;
        }
        const url = el.getAttribute('data-url');
        if (url) {
          __openBookmarkUrl__(url);
        }
      });

      // 删除按钮
      const deleteBtn = el.querySelector('.bookmark-delete-btn');
      if (deleteBtn) {
        deleteBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          const id = el.getAttribute('data-id');
          await deleteBookmark(id);
        });
      }
    });
  }

  async function deleteBookmark(id) {
    if (!id) return;
    const bookmarks = await storageGet('bookmarks') || [];
    const updated = bookmarks.filter(b => b.id !== id);
    await storageSet('bookmarks', updated);
    loadBookmarkData();
    showToast('🗑️ 收藏项已删除');
  }

  async function exportBookmarks() {
    const bookmarks = await storageGet('bookmarks') || [];
    if (bookmarks.length === 0) {
      showToast('⚠️ 收藏夹为空，无法导出');
      return;
    }
    showExportFormatDialog(bookmarks);
  }

  function showExportFormatDialog(bookmarks) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.style.cssText = [
      'position:fixed;inset:0;background:rgba(0,0,0,0.5);',
      'display:flex;align-items:center;justify-content:center;z-index:10000;'
    ].join('');

    const dialog = document.createElement('div');
    dialog.className = 'modal-dialog';
    dialog.innerHTML = [
      '<h3>📥 导出收藏夹</h3>',
      '<p>请选择导出格式：</p>',
      '<div class="modal-actions" style="flex-direction:column;gap:8px;">',
        '<button id="export-json-btn" class="btn btn-primary" style="width:100%;">导出为 JSON（备份文件）</button>',
        '<button id="export-txt-btn" class="btn btn-outline" style="width:100%;">导出为 TXT（纯文本文档）</button>',
        '<button id="export-cancel-btn" class="btn btn-outline" style="width:100%;">取消</button>',
      '</div>'
    ].join('');

    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    const cleanup = () => overlay.remove();

    dialog.querySelector('#export-json-btn').addEventListener('click', () => {
      cleanup();
      exportAsJSON(bookmarks);
    });

    dialog.querySelector('#export-txt-btn').addEventListener('click', () => {
      cleanup();
      exportAsTXT(bookmarks);
    });

    dialog.querySelector('#export-cancel-btn').addEventListener('click', cleanup);
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) cleanup();
    });
  }

  async function exportAsJSON(bookmarks) {
    // 同时读取对话收藏和消息收藏
    const [convBookmarks, msgBookmarks] = await Promise.all([
      storageGet('bookmarks').then(r => r || []),
      storageGet('messageBookmarks').then(r => r || [])
    ]);
    // 合并，为消息收藏标记 type
    const merged = [
      ...convBookmarks.map(b => ({ ...b, type: '对话收藏' })),
      ...msgBookmarks.map(m => ({ ...m, type: '消息收藏' }))
    ];
    const data = JSON.stringify(merged, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `deepseek-bookmarks-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('📥 收藏夹已导出为 JSON');
  }

  async function exportAsTXT(bookmarks) {
    // 同时读取对话收藏和消息收藏
    const [convBookmarks, msgBookmarks] = await Promise.all([
      storageGet('bookmarks').then(r => r || []),
      storageGet('messageBookmarks').then(r => r || [])
    ]);
    // 合并，为消息收藏标记 type
    const merged = [
      ...convBookmarks.map(b => ({ ...b, type: '对话收藏' })),
      ...msgBookmarks.map(m => ({ ...m, type: '消息收藏' }))
    ];
    const lines = [];
    lines.push('DeepSeek助手 - 收藏夹导出');
    lines.push('导出时间：' + new Date().toLocaleString('zh-CN'));
    lines.push('共 ' + merged.length + ' 项收藏（对话收藏 ' + convBookmarks.length + ' 项，消息收藏 ' + msgBookmarks.length + ' 项）');
    lines.push('');
    merged.forEach((b, i) => {
      lines.push('========== 收藏项 ' + (i + 1) + ' ==========');
      lines.push('类型：' + (b.type || ''));
      lines.push('标题：' + (b.title || '无标题'));
      lines.push('网址：' + (b.url || b.conversationUrl || ''));
      if (b.messageRole) {
        lines.push('消息角色：' + b.messageRole);
      }
      if (b.contentText) {
        lines.push('消息内容：' + b.contentText);
      } else if (b.snippet) {
        lines.push('摘要：' + b.snippet);
      }
      if (b.timestamp) {
        lines.push('收藏时间：' + new Date(b.timestamp).toLocaleString('zh-CN'));
      }
      if (b.note) {
        lines.push('备注：' + b.note);
      }
      lines.push('');
    });
    const text = lines.join('\n');
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `deepseek-bookmarks-${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('📥 收藏夹已导出为 TXT');
  }

  async function importBookmarks() {
    const file = dom.importFileInput ? dom.importFileInput.files[0] : null;
    if (!file) return;

    try {
      const text = await file.text();
      const data = JSON.parse(text);
      if (!Array.isArray(data)) {
        showToast('⚠️ 文件格式错误');
        return;
      }
      const existing = await storageGet('bookmarks') || [];
      // 合并去重：URL是主键，URL为空时用标题兜底
      const existingKeys = new Set(existing.map(b => b.url || b.title));
      let added = 0;
      for (const item of data) {
        const key = item.url || item.title || '';
        if (!existingKeys.has(key)) {
          existing.push({
            ...item,
            id: item.id || Date.now().toString() + '_' + Math.random().toString(36).slice(2),
            createdAt: item.createdAt || new Date().toISOString()
          });
          existingKeys.add(key);
          added++;
        }
      }
      await storageSet('bookmarks', existing);
      loadBookmarkData();
      showToast(`📥 成功导入 ${added} 项收藏`);
    } catch (e) {
      showToast('⚠️ 导入失败，请检查文件格式');
    }
    // 重置 file input
    if (dom.importFileInput) dom.importFileInput.value = '';
  }

  function getBookmarkEmptyHTML() {
    return `
      <div class="empty-state">
        <span class="empty-icon">⭐</span>
        <p>收藏夹为空</p>
        <p class="empty-hint">一站式管理重要对话，支持排序、搜索与 JSON/TXT 导出备份</p>
        <p class="empty-hint" style="margin-top:8px;">⭐ 点击页面右下角悬浮按钮，或使用快捷键 Ctrl+Shift+X 收藏当前对话</p>
        <p class="empty-hint" style="margin-top:4px;">🔍 在历史搜索和当前对话搜索结果中，右键对话也可快速收藏</p>
      </div>
    `;
  }

  // ==================== 消息收藏面板 ====================

  async function renderMessageBookmarks(filterQuery) {
    const container = dom.messageBookmarkList;
    if (!container) return;

    const query = (filterQuery || '').toLowerCase();
    let messageBookmarks = await storageGet('messageBookmarks') || [];

    if (query) {
      messageBookmarks = messageBookmarks.filter(m =>
        (m.messageRole && m.messageRole.toLowerCase().includes(query)) ||
        (m.conversationTitle && m.conversationTitle.toLowerCase().includes(query)) ||
        (m.contentText && m.contentText.toLowerCase().includes(query))
      );
    }

    // 按时间倒序
    messageBookmarks.sort((a, b) => b.timestamp - a.timestamp);

    if (messageBookmarks.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <span class="empty-icon">💬</span>
          <p>暂无消息收藏</p>
          <p class="empty-hint">在对话页面中，鼠标悬停消息，点击星标按钮收藏单条消息</p>
        </div>`;
      return;
    }

    container.innerHTML = messageBookmarks.map(m => {
      const roleTag = m.messageRole === 'AI' ? '<span class="role-tag role-ai">🤖 AI回答</span>' : '<span class="role-tag role-user">👤 用户提问</span>';
      const preview = (m.contentText || '').slice(0, 150);
      const title = m.conversationTitle || '未命名对话';
      const time = formatTime(m.timestamp);
      const url = m.url || m.conversationUrl || '';
      const sharedLink = m.sharedLink || (url ? (url + (url.includes('#') ? '&' : '#') + 'ds-msg=' + encodeURIComponent(m.id)) : '');
      // 关键词高亮（仅在有搜索关键词时）
      const highlightedTitle = query ? highlightText(title, query) : escapeHTML(title);
      const highlightedPreview = query && preview ? highlightText(preview, query) : escapeHTML(preview);

      return `
        <div class="msg-bookmark-card" data-id="${escapeHTML(m.id)}" data-url="${escapeHTML(url)}" data-shared-link="${escapeHTML(sharedLink)}" data-role="${escapeHTML(m.messageRole || '')}">
          <div class="msg-card-header">
            ${roleTag}
            <span class="msg-card-time">${escapeHTML(time)}</span>
          </div>
          <div class="msg-card-title">${highlightedTitle}</div>
          <div class="msg-card-preview">${highlightedPreview}</div>
          <div class="list-item-actions">
            <button class="btn btn-outline btn-sm msg-open-btn">打开</button>
            <button class="btn btn-danger-outline btn-sm msg-delete-btn">删除</button>
          </div>
        </div>`;
    }).join('');

    bindMessageCardEvents();
  }

  function bindMessageCardEvents() {
    const cards = dom.messageBookmarkList.querySelectorAll('.msg-bookmark-card');
    cards.forEach((card) => {
      // 打开消息对话（供卡片和按钮共用）
      function openMessageConversation() {
        const sharedLink = card.getAttribute('data-shared-link');
        const url = card.getAttribute('data-url');
        const id = card.getAttribute('data-id');
        if (sharedLink) {
          window.open(sharedLink, '_blank');
          showToast('📍 正在打开对话并定位消息...');
        } else if (url) {
          const separator = url.includes('#') ? '&' : '#';
          const jumpUrl = url + separator + 'ds-msg=' + encodeURIComponent(id);
          window.open(jumpUrl, '_blank');
          showToast('📍 正在打开对话并定位消息...');
        }
      }

      // 卡片整体点击
      card.addEventListener('click', openMessageConversation);

      // 打开按钮
      const openBtn = card.querySelector('.msg-open-btn');
      if (openBtn) {
        openBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          openMessageConversation();
        });
      }

      // 删除按钮
      const deleteBtn = card.querySelector('.msg-delete-btn');
      if (deleteBtn) {
        deleteBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          const id = card.getAttribute('data-id');
          if (!id) return;
          const bookmarks = await storageGet('messageBookmarks') || [];
          const updated = bookmarks.filter(b => b.id !== id);
          await storageSet('messageBookmarks', updated);
          renderMessageBookmarks();
          showToast('🗑️ 消息收藏已删除');
        });
      }
    });
  }

  // ==================== 右键收藏辅助 ====================
  function bookmarkViaContent(title, url, snippet) {
    safeSendMessage({
      action: 'bookmark-from-panel',
      data: { title: title || '', url: url || '', snippet: snippet || '', timestamp: Date.now() }
    }, (response) => {
      if (response && response.success) {
        console.log('[DeepSeek-Assistant][panel:bookmarkViaContent] 收藏成功');
        loadBookmarkData();
      } else if (response && response.error) {
        console.warn('[DeepSeek-Assistant][panel:bookmarkViaContent] 收藏失败:', response.error);
        loadBookmarkData();
      } else {
        console.warn('[DeepSeek-Assistant][panel:bookmarkViaContent] 收藏失败，未知错误');
        loadBookmarkData();
      }
    });
  }

  // ==================== 收藏项 URL 打开策略 ====================

  /**
   * 打开收藏项 URL：
   *   - 分享链接（chat.deepseek.com/share/ 或 chat.deepseek.com/a/chat/s/）→ window.open 新标签页
   *   - 其他 URL → background open-url 中转
   */
  function __openBookmarkUrl__(url) {
    if (!url) return;
    // 判断是否为 DeepSeek 分享链接
    const isDeepSeekUrl = url.includes('chat.deepseek.com');
    if (isDeepSeekUrl) {
      window.open(url, '_blank');
    } else {
      safeSendMessage({ action: 'open-url', url });
    }
  }

  // ==================== 设置重置 =====================

  async function resetSettings() {
    state.theme = 'deep-blue';
    state.customThemeColors = null;
    state.fontSize = 'medium';
    state.enableFloatButton = true;
    state.settings = {
      theme: 'deep-blue',
      customThemeColors: null,
      fontSize: 'medium',
      enableFloatButton: true,
      maxHistoryItems: 50
    };

    // 更新 THEME_DEFINITIONS
    THEME_DEFINITIONS['custom'].primary = '#1890ff';
    THEME_DEFINITIONS['custom'].bg = '#ffffff';
    THEME_DEFINITIONS['custom'].text = '#333333';
    THEME_DEFINITIONS['custom'].name = '创建我的主题';

    await saveSettings();

    // 清除自定义主题残留的内联 CSS 变量，确保默认主题样式生效
    // （applyCustomThemeVars() 会将变量设为 dom.body.style 内联样式，
    //   其优先级高于 CSS 类定义，必须清除后默认主题类才能生效）
    const defaultVars = computeThemeCSSVars('#1890ff', '#ffffff', '#333333');
    Object.keys(defaultVars).forEach(key => dom.body.style.removeProperty(key));

    // 应用默认主题
    applyTheme('deep-blue');
    applyFontSize('medium');

    // 更新浮动按钮开关
    if (dom.toggleFloatBtn) dom.toggleFloatBtn.checked = true;

    // 重新渲染卡片
    renderThemeCards();

    // 更新字体 radio
    document.querySelectorAll('.font-option input[type="radio"]').forEach(r => {
      r.checked = r.value === 'medium';
    });

    // 同步到 content
    safeSendMessage({
      action: 'settings-changed',
      settings: state.settings
    });

    showToast('✅ 已恢复默认设置');
  }

  // ==================== Toast 提示 ====================

  function showToast(message) {
    // 确保 toast 容器存在
    let container = document.querySelector('.toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    container.appendChild(toast);

    setTimeout(() => {
      if (toast.parentNode) toast.remove();
    }, 2700);
  }

  // ==================== 排序切换 ====================

  function toggleHistorySort() {
    state.historySortOrder = state.historySortOrder === 'desc' ? 'asc' : 'desc';
    updateHistorySortLabel();
    loadHistoryData();
  }

  function updateHistorySortLabel() {
    if (dom.btnHistorySort) {
      dom.btnHistorySort.textContent = state.historySortOrder === 'desc' ? '时间正序' : '时间倒序';
    }
  }

  function toggleCurrentSort() {
    state.currentSortOrder = state.currentSortOrder === 'desc' ? 'asc' : 'desc';
    if (dom.btnCurrentSort) {
      dom.btnCurrentSort.textContent = state.currentSortOrder === 'desc' ? '时间正序' : '时间倒序';
    }
    // 重新排序并渲染已有结果
    if (state.currentSearchResults.length > 0) {
      const sorted = [...state.currentSearchResults];
      if (state.currentSortOrder === 'desc') {
        sorted.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
      } else {
        sorted.sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
      }
      renderSearchResults(sorted, state.currentSearchQuery);
    }
  }

  // ==================== 工具函数 ====================

  function escapeHTML(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function highlightText(text, query) {
    if (!text || !query) return escapeHTML(text);
    const escapedText = escapeHTML(text);
    const escapedQuery = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escapedQuery})`, 'gi');
    return escapedText.replace(regex, '<mark>$1</mark>');
  }

  function formatTime(timestamp) {
    if (!timestamp) return '';
    const d = new Date(timestamp);
    const now = new Date();
    const diffMs = now - d;
    const diffMin = Math.floor(diffMs / 60000);
    if (diffMin < 1) return '刚刚';
    if (diffMin < 60) return diffMin + '分钟前';
    const diffHour = Math.floor(diffMin / 60);
    if (diffHour < 24) return diffHour + '小时前';
    const diffDay = Math.floor(diffHour / 24);
    if (diffDay < 7) return diffDay + '天前';
    return d.toLocaleDateString('zh-CN');
  }

  function debounce(fn, delay) {
    let timer;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), delay);
    };
  }

  // ==================== content-ready 兜底定时器 ====================
  function startContentReadyFallback() {
    if (contentReadyFallbackTimer) return;
    contentReadyFallbackTimer = setTimeout(() => {
      contentReady = true;
      contentReadyFallbackTimer = null;
      if (state.currentTab === 'history-search') {
        loadHistoryData();
      }
    }, 3000);
  }

  // ==================== 暴露 API 到 window ====================

  window.DSAssistant = {
    getState: () => state,
    switchTab,
    showToast,
    applyTheme,
    renderThemeCards,
    loadHistoryData,
    loadBookmarkData,
    renderBookmarkList: loadBookmarkData,
    renderHistoryList: loadHistoryData,
    getEffectiveTheme
  };

  // 添加搜索历史（供 content.js 调用）
  window.addSearchHistory = async function (entry) {
    let history = await storageGet('searchHistory') || [];
    history.unshift({
      query: entry.query || '',
      type: entry.type || '搜索',
      title: entry.title || '',
      url: entry.url || '',
      timestamp: Date.now()
    });
    // 限制数量
    const maxItems = state.settings.maxHistoryItems || 50;
    if (history.length > maxItems) {
      history = history.slice(0, maxItems);
    }
    await storageSet('searchHistory', history);
    if (state.currentTab === 'history-search') {
      loadHistoryData();
    }
  };

  // ==================== 启动 ====================

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();