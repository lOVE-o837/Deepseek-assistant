// content-core.js — 主入口、初始化、消息监听、与 background 通信
// 拆分自原 content.js 的入口逻辑
// ⚠️ 本文件将替换原 content.js，请确认无误后删除原文件
