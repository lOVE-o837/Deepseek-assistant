// content-sidebar.js — 左侧侧边栏对话列表抓取
// 拆分自原 content.js 的 fetchSidebarConversations 及相关函数
