// content-panel.js — 面板 iframe 通信 + 拖拽 + 位置记忆
// 拆分自原 content.js 的 injectPanelIframe、togglePanel、drag 相关函数
