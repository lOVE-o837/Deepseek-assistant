// content-bookmark.js — 对话/消息收藏触发逻辑 + 星标按钮注入
// 拆分自原 content.js 的 bookmarkCurrentPage、handleMessageBookmark 及相关函数
// 合并对话收藏和消息收藏的页面注入逻辑，两者高度相似适合放一起
