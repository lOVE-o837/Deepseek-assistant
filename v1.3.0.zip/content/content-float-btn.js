// content-float-btn.js — 悬浮按钮 + 长按菜单 + 尺寸切换
// 拆分自原 content.js 的 injectFloatButton、showFloatMenu 及相关函数
