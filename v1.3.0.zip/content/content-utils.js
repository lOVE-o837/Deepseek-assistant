// content-utils.js — 纯工具函数
// 拆分自原 content.js 的 getTrustedTitle、waitForMessageElement、
// findMessageElement、showToast、escapeHTML 等不依赖业务状态的函数
