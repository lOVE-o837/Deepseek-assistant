// content-search.js — 当前页面内容搜索
// 拆分自原 content.js 的 searchCurrentPage、scrollToResult 及相关函数
